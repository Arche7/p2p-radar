// ⚠️ Этот файл собирается автоматически командой `bun build.ts` из папки src/. Правьте исходники в src/.
// ─────────────────────────────────────────────────────────────────────────────
//  P2P Radar — Telegram-бот + Mini App для мониторинга Bybit P2P (покупка USDT)
//  Один файл, без внешних зависимостей. Рантайм: Bun (bun:sqlite встроен).
// ─────────────────────────────────────────────────────────────────────────────
import { Database } from "bun:sqlite";
import { createHmac } from "node:crypto";
import { mkdirSync } from "node:fs";

// Эти две константы подставляет build.ts (HTML мини-приложения и логотип)
const APP_HTML: string = `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
<meta name="color-scheme" content="dark light">
<title>P2P Radar</title>
<link rel="icon" href="/logo.svg">
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{
  --bg:#07070d;--bg2:#120c24;--text:#f5f3ff;--muted:rgba(236,234,255,.58);--faint:rgba(236,234,255,.32);
  --glass:rgba(255,255,255,.065);--glass2:rgba(255,255,255,.11);--stroke:rgba(255,255,255,.12);
  --edge1:rgba(255,255,255,.55);--edge2:rgba(255,255,255,.14);--shadow:0 18px 40px rgba(0,0,0,.45);
  --a1:#FFC24B;--a2:#FF7A2F;--a3:#FF4D6D;--mint:#34E3A4;--red:#FF5A6A;--blue:#6EA8FF;
  --grad:linear-gradient(120deg,var(--a1),var(--a2) 55%,var(--a3));
  --r:24px;--safe-b:env(safe-area-inset-bottom,0px);
  font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Inter","Segoe UI",Roboto,sans-serif;
}
[data-theme=light]{
  --bg:#eceef8;--bg2:#f7f1ff;--text:#15121f;--muted:rgba(21,18,31,.58);--faint:rgba(21,18,31,.35);
  --glass:rgba(255,255,255,.48);--glass2:rgba(255,255,255,.7);--stroke:rgba(255,255,255,.75);
  --edge1:rgba(255,255,255,.95);--edge2:rgba(255,255,255,.4);--shadow:0 14px 34px rgba(40,30,90,.14);
}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0}
html,body{background:var(--bg);color:var(--text);min-height:100%;overscroll-behavior:none}
body{font-size:15px;line-height:1.35;-webkit-font-smoothing:antialiased;overflow-x:hidden}
button,input,select{font:inherit;color:inherit;border:0;background:none;outline:none}
button{cursor:pointer}
.bg{position:fixed;inset:0;z-index:0;overflow:hidden;background:radial-gradient(120% 80% at 50% -10%,var(--bg2),var(--bg) 60%)}
.bg i{position:absolute;border-radius:50%;filter:blur(70px);opacity:.55;animation:float 22s ease-in-out infinite alternate}
.bg .b1{width:340px;height:340px;background:#FF7A2F;top:-90px;right:-90px}
.bg .b2{width:300px;height:300px;background:#7B3BFF;top:38%;left:-130px;animation-duration:27s;opacity:.45}
.bg .b3{width:260px;height:260px;background:#FF4D6D;bottom:-60px;right:-40px;animation-duration:31s;opacity:.35}
.bg .b4{width:180px;height:180px;background:#34E3A4;top:58%;right:20%;opacity:.16;animation-duration:35s}
[data-theme=light] .bg i{opacity:.32}
@keyframes float{0%{transform:translate(0,0) scale(1)}50%{transform:translate(40px,60px) scale(1.15)}100%{transform:translate(-30px,20px) scale(.95)}}

.glass{position:relative;background:linear-gradient(145deg,var(--glass2),var(--glass) 60%);
  -webkit-backdrop-filter:blur(26px) saturate(170%);backdrop-filter:blur(26px) saturate(170%);
  border-radius:var(--r);box-shadow:inset 0 1px 0 rgba(255,255,255,.18),var(--shadow)}
.glass::before{content:"";position:absolute;inset:0;border-radius:inherit;padding:1px;pointer-events:none;
  background:linear-gradient(150deg,var(--edge1),rgba(255,255,255,0) 38%,rgba(255,255,255,0) 62%,var(--edge2));
  -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude}

#app{position:relative;z-index:1;max-width:560px;margin:0 auto;padding:14px 16px calc(110px + var(--safe-b))}
.top{display:flex;align-items:center;gap:12px;padding:6px 2px 16px}
.top img{width:40px;height:40px;filter:drop-shadow(0 6px 16px rgba(255,122,47,.35))}
.top h1{font-size:20px;font-weight:750;letter-spacing:-.02em}
.top small{display:block;color:var(--muted);font-size:12.5px;font-weight:500;margin-top:1px}
.pill{margin-left:auto;display:flex;align-items:center;gap:7px;padding:8px 12px;border-radius:99px;font-size:12.5px;font-weight:650}
.dot{width:8px;height:8px;border-radius:50%;background:var(--mint);box-shadow:0 0 0 0 rgba(52,227,164,.7);animation:ping 1.8s infinite}
.dot.off{background:var(--faint);animation:none;box-shadow:none}
.dot.err{background:var(--red);animation:none;box-shadow:0 0 10px var(--red)}
@keyframes ping{0%{box-shadow:0 0 0 0 rgba(52,227,164,.65)}80%,100%{box-shadow:0 0 0 9px rgba(52,227,164,0)}}

.view{display:none;animation:in .35s cubic-bezier(.2,.8,.2,1)}
.view.on{display:block}
@keyframes in{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

.hero{padding:20px;overflow:hidden;margin-bottom:22px}
.hero .lbl{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:13px;font-weight:600}
.price{font-size:46px;font-weight:800;letter-spacing:-.035em;line-height:1.05;margin:10px 0 4px;
  background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent;font-variant-numeric:tabular-nums}
.price.loading{background:linear-gradient(90deg,var(--glass2),var(--edge2),var(--glass2));background-size:200% 100%;-webkit-background-clip:text;animation:sh 1.2s infinite linear}
@keyframes sh{to{background-position:-200% 0}}
.hero .sub{color:var(--muted);font-size:13px}
.hero .row{display:flex;gap:10px;margin-top:16px}
.radar{position:absolute;right:-34px;top:-30px;width:170px;height:170px;border-radius:50%;opacity:.55;pointer-events:none;
  background:repeating-radial-gradient(circle,rgba(255,255,255,.14) 0 1px,transparent 1px 28px)}
.radar::after{content:"";position:absolute;inset:0;border-radius:50%;
  background:conic-gradient(from 0deg,rgba(255,194,75,.55),rgba(255,122,47,.18) 40deg,transparent 90deg);animation:spin 4s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.chipsel{position:relative;margin-left:auto}
.chipsel select{appearance:none;-webkit-appearance:none;padding:6px 26px 6px 12px;border-radius:99px;font-weight:700;font-size:13px;color:var(--text);background:var(--glass2);border:1px solid var(--stroke)}
.chipsel::after{content:"▾";position:absolute;right:10px;top:50%;transform:translateY(-50%);font-size:11px;color:var(--muted);pointer-events:none}
.chipsel option{color:#111}

.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:13px 16px;border-radius:16px;font-weight:700;font-size:14.5px;transition:transform .15s,opacity .15s;white-space:nowrap}
.btn:active{transform:scale(.96)}
.btn.g{background:var(--glass2);border:1px solid var(--stroke)}
.btn.p{background:var(--grad);color:#1b0d00;box-shadow:0 10px 26px rgba(255,122,47,.35),inset 0 1px 0 rgba(255,255,255,.5)}
.btn.w{flex:1}
.btn.sm{padding:9px 12px;font-size:13px;border-radius:12px}
.btn.danger{color:var(--red)}
.btn svg{width:18px;height:18px}

.sec{display:flex;align-items:center;justify-content:space-between;margin:4px 4px 12px}
.sec h2{font-size:19px;font-weight:750;letter-spacing:-.02em}
.sec .cnt{color:var(--muted);font-weight:600;font-size:14px;margin-left:6px}

.fcard{padding:16px;margin-bottom:12px}
.fhead{display:flex;align-items:center;gap:10px}
.fhead b{font-size:16.5px;font-weight:720;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{font-size:11px;font-weight:750;padding:3px 8px;border-radius:99px;background:var(--glass2);border:1px solid var(--stroke);color:var(--muted);letter-spacing:.03em}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0 12px}
.cell{padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid var(--stroke)}
[data-theme=light] .cell{background:rgba(255,255,255,.45)}
.cell span{display:block;color:var(--muted);font-size:11.5px;font-weight:650;text-transform:uppercase;letter-spacing:.05em}
.cell b{display:block;font-size:15px;font-weight:720;margin-top:3px;font-variant-numeric:tabular-nums}
.chips{display:flex;flex-wrap:wrap;gap:6px}
.chip{font-size:12.5px;font-weight:600;padding:5px 10px;border-radius:99px;background:rgba(255,255,255,.07);border:1px solid var(--stroke);color:var(--text)}
[data-theme=light] .chip{background:rgba(255,255,255,.6)}
.chip.dim{color:var(--muted)}
.ffoot{display:flex;align-items:center;gap:8px;margin-top:14px;padding-top:12px;border-top:1px solid var(--stroke)}
.match{flex:1;min-width:0;display:flex;align-items:center;gap:6px;font-size:13.5px;color:var(--muted);font-weight:600;white-space:nowrap;overflow:hidden}
.match span:last-child{overflow:hidden;text-overflow:ellipsis}
.match b{color:var(--text);font-size:15px}
.match.hot b{color:var(--mint)}
.ibtn{width:36px;height:36px;border-radius:12px;display:grid;place-items:center;background:var(--glass2);border:1px solid var(--stroke)}
.ibtn svg{width:17px;height:17px;opacity:.85}
.ibtn:active{transform:scale(.92)}

.sw{position:relative;width:51px;height:31px;border-radius:99px;background:rgba(255,255,255,.14);transition:background .25s;flex:none;border:1px solid var(--stroke)}
[data-theme=light] .sw{background:rgba(0,0,0,.12)}
.sw::after{content:"";position:absolute;top:2px;left:2px;width:25px;height:25px;border-radius:50%;background:#fff;box-shadow:0 3px 8px rgba(0,0,0,.3);transition:transform .25s cubic-bezier(.3,1.4,.5,1)}
.sw.on{background:linear-gradient(120deg,#2fd895,#34E3A4)}
.sw.on::after{transform:translateX(20px)}

.empty{padding:30px 22px;text-align:center}
.empty .ill{width:96px;height:96px;margin:0 auto 14px;border-radius:50%;position:relative;
  background:repeating-radial-gradient(circle,rgba(255,255,255,.16) 0 1px,transparent 1px 16px);border:1px solid var(--stroke);overflow:hidden}
.empty .ill::after{content:"";position:absolute;inset:0;background:conic-gradient(from 0deg,rgba(255,194,75,.7),transparent 80deg);animation:spin 3s linear infinite;border-radius:50%}
.empty h3{font-size:18px;font-weight:750;margin-bottom:6px}
.empty p{color:var(--muted);font-size:14px;margin-bottom:18px}

.seg{display:flex;padding:4px;border-radius:16px;margin-bottom:14px}
.seg button{flex:1;padding:10px 6px;border-radius:12px;font-weight:700;font-size:13.5px;color:var(--muted);transition:all .25s}
.seg button.on{background:var(--glass2);color:var(--text);box-shadow:inset 0 1px 0 rgba(255,255,255,.25),0 4px 14px rgba(0,0,0,.2)}
.hscroll{display:flex;gap:8px;overflow-x:auto;padding:2px 2px 12px;scrollbar-width:none;margin:0 -16px;padding-left:16px;padding-right:16px}
.hscroll::-webkit-scrollbar{display:none}
.tag{flex:none;padding:8px 14px;border-radius:99px;font-size:13px;font-weight:650;background:var(--glass);border:1px solid var(--stroke);color:var(--muted);transition:all .2s}
.tag.on{background:var(--grad);color:#1b0d00;border-color:transparent;box-shadow:0 6px 16px rgba(255,122,47,.3)}

.ad{padding:16px;margin-bottom:12px}
.adtop{display:flex;align-items:flex-start;gap:10px}
.adprice{font-size:26px;font-weight:800;letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.adprice small{font-size:15px;color:var(--muted);font-weight:650;margin-left:3px}
.adwho{margin-left:auto;text-align:right;font-size:13px;color:var(--muted)}
.adwho b{color:var(--text);font-weight:700;font-size:14px;display:flex;align-items:center;gap:5px;justify-content:flex-end}
.on-dot{width:7px;height:7px;border-radius:50%;background:var(--mint);box-shadow:0 0 8px var(--mint)}
.off-dot{width:7px;height:7px;border-radius:50%;background:var(--faint)}
.ver{display:inline-grid;place-items:center;width:16px;height:16px;border-radius:50%;background:var(--blue);color:#fff;font-size:10px;font-weight:900}
.adrows{display:grid;gap:6px;margin:12px 0;font-size:13.5px}
.adrows div{display:flex;justify-content:space-between;gap:10px}
.adrows span{color:var(--muted)}
.adrows b{font-weight:650;text-align:right;font-variant-numeric:tabular-nums}
.req{font-size:12.5px;color:#FFB86B;margin-top:10px;display:flex;gap:6px}
[data-theme=light] .req{color:#b4560b}
.adact{display:flex;gap:8px;margin-top:14px}
.meta{font-size:12px;color:var(--faint);margin-top:10px;display:flex;justify-content:space-between}
.remark{font-size:12.5px;color:var(--muted);margin-top:10px;padding:10px 12px;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid var(--stroke);white-space:pre-wrap;max-height:84px;overflow:hidden;position:relative}
.remark.open{max-height:none}

.set{padding:6px 16px;margin-bottom:14px}
.srow{display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--stroke)}
.srow:last-child{border-bottom:0}
.srow .ic{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;font-size:17px;flex:none;background:var(--glass2);border:1px solid var(--stroke)}
.srow .tx{flex:1;min-width:0}
.srow .tx b{display:block;font-weight:650;font-size:15px}
.srow .tx small{display:block;color:var(--muted);font-size:12.5px;margin-top:2px}
.note{font-size:13.5px;color:var(--muted);line-height:1.5;padding:14px 0}
.note b{color:var(--text)}
.stitle{font-size:12.5px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin:18px 6px 8px}

.tabbar{background:rgba(20,15,36,.72)!important;-webkit-backdrop-filter:blur(30px) saturate(180%)!important;backdrop-filter:blur(30px) saturate(180%)!important;position:fixed;z-index:20;left:50%;transform:translateX(-50%);bottom:calc(14px + var(--safe-b));display:flex;gap:4px;padding:6px;border-radius:26px;width:min(92vw,380px)}
.tabbar button{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;padding:8px 4px;border-radius:20px;font-size:11px;font-weight:700;color:var(--muted);transition:all .25s;position:relative}
.tabbar button svg{width:22px;height:22px}
.tabbar button.on{color:var(--text);background:var(--glass2);box-shadow:inset 0 1px 0 rgba(255,255,255,.28)}
.tabbar button.on svg{color:var(--a2)}
.tabbar .nb{position:absolute;top:4px;right:calc(50% - 22px);min-width:17px;height:17px;padding:0 4px;border-radius:99px;background:var(--mint);color:#002;font-size:10.5px;font-weight:800;display:none;place-items:center}

.ov{position:fixed;inset:0;z-index:40;background:rgba(5,4,12,.45);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);opacity:0;pointer-events:none;transition:opacity .3s}
.ov.on{opacity:1;pointer-events:auto}
.sheet{position:fixed;z-index:41;left:0;right:0;bottom:0;max-width:560px;margin:0 auto;max-height:92vh;overflow-y:auto;border-radius:30px 30px 0 0;
  padding:10px 18px calc(22px + var(--safe-b));transform:translateY(105%);transition:transform .42s cubic-bezier(.2,.9,.25,1);
  background:linear-gradient(160deg,rgba(40,30,70,.82),rgba(14,11,26,.9));-webkit-backdrop-filter:blur(30px) saturate(170%);backdrop-filter:blur(30px) saturate(170%);
  box-shadow:0 -20px 50px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.25)}
[data-theme=light] .sheet{background:linear-gradient(160deg,rgba(255,255,255,.88),rgba(244,240,255,.92))}
.sheet.on{transform:none}
.grab{width:40px;height:5px;border-radius:99px;background:var(--faint);margin:0 auto 14px}
.sheet h3{font-size:21px;font-weight:780;letter-spacing:-.02em;margin-bottom:4px}
.field{margin-top:18px}
.field>label{display:block;font-size:12.5px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin:0 4px 8px}
.inp{width:100%;padding:14px 16px;border-radius:16px;background:rgba(255,255,255,.07);border:1px solid var(--stroke);font-size:16px;font-weight:600;transition:border .2s,box-shadow .2s}
[data-theme=light] .inp{background:rgba(255,255,255,.75)}
.inp:focus{border-color:rgba(255,160,70,.8);box-shadow:0 0 0 4px rgba(255,122,47,.18)}
.pair{display:flex;align-items:center;gap:8px}
.pair .w{position:relative;flex:1}
.pair .w .inp{padding-right:58px}
.pair .w em{position:absolute;right:14px;top:50%;transform:translateY(-50%);font-style:normal;font-size:12.5px;font-weight:700;color:var(--muted)}
.pair i{color:var(--faint);font-style:normal}
.hint{font-size:12.5px;color:var(--muted);margin:8px 4px 0}
.hint b{color:var(--text)}
.quick{display:flex;gap:6px;margin-top:10px;flex-wrap:wrap}
.quick button{padding:7px 11px;border-radius:99px;font-size:12.5px;font-weight:650;background:rgba(255,255,255,.06);border:1px solid var(--stroke)}
.quick button.on,.pchip.on{background:var(--grad);color:#1b0d00;border-color:transparent}
.pchip{padding:8px 12px;border-radius:99px;font-size:13px;font-weight:650;background:rgba(255,255,255,.06);border:1px solid var(--stroke);transition:all .15s}
.pchip small{opacity:.6;margin-left:4px;font-weight:600}
.preview{margin-top:20px;padding:14px 16px;border-radius:18px;display:flex;align-items:center;gap:12px;background:rgba(52,227,164,.08);border:1px solid rgba(52,227,164,.3)}
.preview b{font-size:22px;color:var(--mint);font-variant-numeric:tabular-nums}
.preview span{font-size:13px;color:var(--muted)}
.preview.zero{background:rgba(255,255,255,.04);border-color:var(--stroke)}
.preview.zero b{color:var(--muted)}
.trow{display:flex;align-items:center;gap:12px;padding:12px 4px}
.trow div{flex:1}
.trow b{display:block;font-weight:650}
.trow small{color:var(--muted);font-size:12.5px}
.sheet .acts{display:flex;gap:10px;margin:14px -18px 0;padding:18px 18px 4px;position:sticky;bottom:-1px;background:linear-gradient(rgba(16,12,30,0),rgba(16,12,30,.96) 28%)}
[data-theme=light] .sheet .acts{background:linear-gradient(rgba(246,242,255,0),rgba(246,242,255,.97) 28%)}
[data-theme=light] .tabbar{background:rgba(255,255,255,.72)!important}

#toast{position:fixed;z-index:60;left:50%;top:14px;transform:translate(-50%,-140%);padding:12px 18px;border-radius:18px;font-weight:650;font-size:14px;transition:transform .4s cubic-bezier(.2,.9,.3,1.2);max-width:90vw;text-align:center}
#toast.on{transform:translate(-50%,0)}
.skel{height:150px;border-radius:var(--r);margin-bottom:12px;background:linear-gradient(90deg,var(--glass),var(--glass2),var(--glass));background-size:200% 100%;animation:sh 1.3s infinite linear}
.err{padding:14px 16px;margin-bottom:14px;border-radius:18px;background:rgba(255,90,106,.12);border:1px solid rgba(255,90,106,.35);font-size:13.5px}
</style>
</head>
<body>
<div class="bg"><i class="b1"></i><i class="b2"></i><i class="b3"></i><i class="b4"></i></div>

<div id="app">
  <header class="top">
    <img src="/logo.svg" alt="">
    <div><h1>P2P Radar</h1><small>Bybit P2P · покупка USDT</small></div>
    <div class="pill glass" id="live"><span class="dot off"></span><span>…</span></div>
  </header>

  <section class="view on" id="v-radar">
    <div class="glass hero">
      <div class="radar"></div>
      <div class="lbl">Лучший курс сейчас
        <label class="chipsel"><select id="fiatSel"></select></label>
      </div>
      <div class="price loading" id="bestPrice">00,00 ₽</div>
      <div class="sub" id="bestSub">Загружаем стакан Bybit…</div>
      <div class="row">
        <button class="btn g w" data-act="toggle-monitor" id="monBtn">⏸ Пауза</button>
        <button class="btn g w" data-act="open-list">📋 Стакан Bybit</button>
      </div>
    </div>
    <div id="errBox"></div>
    <div class="sec"><h2>Мои фильтры<span class="cnt" id="fCount"></span></h2>
      <button class="btn p sm" data-act="new-filter">＋ Новый</button></div>
    <div id="filters"><div class="skel"></div></div>
  </section>

  <section class="view" id="v-feed">
    <div class="seg glass" id="feedSeg">
      <button data-seg="match" class="on">Подходят</button>
      <button data-seg="market">Весь стакан</button>
      <button data-seg="hist">История</button>
    </div>
    <div class="hscroll" id="feedTags"></div>
    <div id="feed"></div>
  </section>

  <section class="view" id="v-set">
    <div class="stitle">Уведомления</div>
    <div class="glass set">
      <div class="srow"><div class="ic">📡</div><div class="tx"><b>Мониторинг</b><small id="monTxt">Проверка каждые … сек</small></div><button class="sw" data-act="set-paused" id="swMon"></button></div>
      <div class="srow"><div class="ic">🔕</div><div class="tx"><b>Без звука</b><small>Уведомления приходят тихо</small></div><button class="sw" data-act="set-silent" id="swSil"></button></div>
      <div class="srow"><div class="ic">⏸</div><div class="tx"><b>Пауза на время</b><small id="pauseTxt">Временно не присылать</small></div>
        <button class="btn g sm" data-act="pause" data-min="60">1 ч</button><button class="btn g sm" data-act="pause" data-min="480">8 ч</button></div>
      <div class="srow"><div class="ic">🧪</div><div class="tx"><b>Тестовое уведомление</b><small>Пришлю лучшее объявление в чат</small></div><button class="btn p sm" data-act="test">Отправить</button></div>
    </div>

    <div class="stitle">Скрытые продавцы</div>
    <div class="glass set" id="blList"></div>

    <div class="stitle">Как открывается Bybit</div>
    <div class="glass set"><div class="note">
      Кнопка <b>«⚡ Открыть в Bybit»</b> ведёт прямо на страницу продавца с его объявлением. Если на телефоне установлено приложение Bybit и вы в нём авторизованы, ссылка откроется в нём — сразу в вашем аккаунте.<br><br>
      Если открылся браузер — войдите в Bybit один раз, дальше сессия сохранится. Покупку подтверждаете вы сами: бот <b>никогда не просит пароли и ключи</b> и не совершает сделок за вас.
    </div></div>

    <div class="stitle">О приложении</div>
    <div class="glass set"><div class="note" id="about">P2P Radar</div></div>
  </section>
</div>

<nav class="tabbar glass">
  <button data-tab="radar" class="on"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><path d="M12 12 18.4 5.6"/></svg>Радар</button>
  <button data-tab="feed"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h10"/></svg>Лента<span class="nb" id="feedNb"></span></button>
  <button data-tab="set"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg>Настройки</button>
</nav>

<div class="ov" id="ov" data-act="close-sheet"></div>
<div class="sheet" id="sheet"></div>
<div id="toast" class="glass"></div>

<script>
(function(){
"use strict";
var tg = window.Telegram && window.Telegram.WebApp;
var INIT = (tg && tg.initData) || "";
var $ = function(s){ return document.querySelector(s); };
var S = { me:null, filters:[], fiats:["RUB"], signs:{RUB:"₽"}, market:{}, hits:[], fiat:"RUB", tab:"radar", seg:"match", tag:"all", poll:6, status:null, editing:null };

/* ---------- Telegram ---------- */
function tgInit(){
  if(!tg) return;
  try{ tg.ready(); tg.expand(); }catch(e){}
  var light = tg.colorScheme === "light";
  document.documentElement.setAttribute("data-theme", light ? "light" : "dark");
  try{ tg.setHeaderColor(light ? "#eceef8" : "#07070d"); tg.setBackgroundColor(light ? "#eceef8" : "#07070d"); }catch(e){}
  try{ if(tg.disableVerticalSwipes) tg.disableVerticalSwipes(); }catch(e){}
  try{ tg.onEvent("themeChanged", tgInit); }catch(e){}
  try{ tg.BackButton.onClick(function(){ if($("#sheet").classList.contains("on")) closeSheet(); else go("radar"); }); }catch(e){}
}
function haptic(t){ try{ if(!tg||!tg.HapticFeedback) return; if(t==="ok"||t==="error"||t==="warning") tg.HapticFeedback.notificationOccurred(t==="ok"?"success":t); else if(t==="sel") tg.HapticFeedback.selectionChanged(); else tg.HapticFeedback.impactOccurred(t||"light"); }catch(e){} }
function openUrl(u){ haptic("medium"); try{ if(tg && tg.openLink){ tg.openLink(u,{try_instant_view:false}); return; } }catch(e){} window.open(u,"_blank"); }
function confirmBox(text, cb){ try{ if(tg && tg.showConfirm && tg.isVersionAtLeast && tg.isVersionAtLeast("6.2")){ tg.showConfirm(text, cb); return; } }catch(e){} cb(window.confirm(text)); }

/* ---------- utils ---------- */
function esc(s){ return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];}); }
function fmt(n,d){ if(d==null) d=2; return Number(n||0).toLocaleString("ru-RU",{minimumFractionDigits:d,maximumFractionDigits:d}); }
function fq(n){ n=Number(n||0); return fmt(n, n>=1000||Number.isInteger(n) ? 0 : 2); }
function sign(f){ return S.signs[f] || f; }
function ago(t){ if(!t) return "—"; var s=Math.max(0,Math.round((Date.now()-t)/1000)); if(s<60) return s+" с назад"; var m=Math.round(s/60); if(m<60) return m+" мин назад"; var h=Math.round(m/60); if(h<24) return h+" ч назад"; return Math.round(h/24)+" дн назад"; }
function num(v){ var n=Number(String(v==null?"":v).replace(",",".").split(" ").join("")); return isFinite(n)&&n>0?n:0; }
var toastT;
function toast(t, kind){ var el=$("#toast"); el.textContent=t; el.classList.add("on"); clearTimeout(toastT); toastT=setTimeout(function(){el.classList.remove("on");},2600); if(kind) haptic(kind); }

function api(path, opt){
  opt = opt || {};
  return fetch(path,{method:opt.method||"GET",headers:{"content-type":"application/json","x-init-data":INIT},body:opt.body?JSON.stringify(opt.body):undefined})
    .then(function(r){ return r.json().then(function(j){ if(!r.ok) throw new Error(j.error||("HTTP "+r.status)); return j; }); });
}

/* ---------- matching (как на сервере) ---------- */
function matches(a,f){
  var bl=(S.me&&S.me.blacklist)||[];
  if(a.fiat!==f.fiat) return false;
  if(f.price_min && a.price<f.price_min) return false;
  if(f.price_max && a.price>f.price_max) return false;
  if(a.maxUsdt+1e-9<a.minUsdt) return false;
  if(f.usdt_max && a.minUsdt>f.usdt_max+1e-9) return false;
  if(f.usdt_min && a.maxUsdt+1e-9<f.usdt_min) return false;
  if(f.payments && f.payments.length && !a.payments.some(function(p){return f.payments.indexOf(p)>=0;})) return false;
  if(f.min_rate && a.rate<f.min_rate) return false;
  if(f.min_orders && a.orders<f.min_orders) return false;
  if(f.only_online && !a.online) return false;
  if(f.only_verified && !a.verified) return false;
  if(bl.some(function(b){return b.id===a.maskId;})) return false;
  return true;
}
function payName(fiat,id){ var m=S.market[fiat]; if(m){ for(var i=0;i<m.payments.length;i++) if(m.payments[i].id===id) return m.payments[i].name; } return "#"+id; }

/* ---------- data ---------- */
function loadState(){
  return api("/api/state").then(function(j){
    S.me=j.user; S.filters=j.filters; S.fiats=j.fiats; S.signs=j.signs; S.poll=j.poll; S.status=j.status; S.bot=j.bot; S.version=j.version;
    if(!S.fiatTouched) S.fiat=j.user.fiat||"RUB";
    renderAll();
  });
}
function loadMarket(fiat){
  fiat=fiat||S.fiat;
  return api("/api/market?fiat="+fiat).then(function(m){ S.market[fiat]=m; renderAll(); return m; });
}
function loadHits(){ return api("/api/hits").then(function(j){ S.hits=j.hits; if(S.tab==="feed") renderFeed(); }); }
function refresh(){ return Promise.all([loadState(), loadMarket(S.fiat)]).catch(onErr); }
function onErr(e){
  var msg = String(e && e.message || e);
  if(msg==="unauthorized"||msg==="forbidden"){
    $("#filters").innerHTML='<div class="glass empty"><div class="ill"></div><h3>Откройте через Telegram</h3><p>'+(msg==="forbidden"?"Доступ к этому радару закрыт владельцем.":"Мини-приложение работает только внутри бота.")+'</p></div>';
    $("#bestPrice").classList.remove("loading"); $("#bestSub").textContent="";
    return;
  }
  toast("⚠️ "+msg,"error");
}

/* ---------- render ---------- */
function renderAll(){ renderHead(); renderRadar(); renderSettings(); if(S.tab==="feed") renderFeed(); }

function renderHead(){
  var el=$("#live"), st=S.status, me=S.me; if(!me) return;
  var paused = me.paused || me.pauseUntil;
  var m = S.market[S.fiat];
  var bad = (st && !st.ok) || (m && m.error && !m.ads.length);
  el.innerHTML = paused ? '<span class="dot off"></span><span>Пауза</span>' : bad ? '<span class="dot err"></span><span>Нет связи</span>' : '<span class="dot"></span><span>Live · '+S.poll+'с</span>';
  var act = S.filters.filter(function(f){return f.active;}).length;
  var nb=$("#feedNb"), cnt=countMatches();
  nb.style.display = cnt? "grid":"none"; nb.textContent = cnt>99?"99+":cnt;
  $("#fCount").textContent = S.filters.length ? (act+"/"+S.filters.length) : "";
}
function countMatches(){ return feedMatches("all").length; }

function renderRadar(){
  var sel=$("#fiatSel");
  if(sel.options.length!==S.fiats.length){ sel.innerHTML=S.fiats.map(function(f){return '<option value="'+f+'">USDT/'+f+'</option>';}).join(""); }
  sel.value=S.fiat;
  var m=S.market[S.fiat], bp=$("#bestPrice");
  if(m){
    bp.classList.remove("loading");
    if(m.ads.length){
      bp.textContent = fmt(m.ads[0].price)+" "+m.sign;
      var top=m.ads.slice(0,10), avg=top.reduce(function(s,a){return s+a.price;},0)/top.length;
      $("#bestSub").innerHTML = 'Среднее топ‑10: <b>'+fmt(avg)+" "+m.sign+'</b> · '+fq(m.total)+' объявл. · '+ago(m.at);
    } else { bp.textContent="—"; $("#bestSub").textContent = m.error ? "Bybit сейчас не отвечает: "+m.error : "Объявлений нет"; }
  }
  var me=S.me;
  if(me){ $("#monBtn").innerHTML = (me.paused||me.pauseUntil) ? "▶️ Включить" : "⏸ Пауза"; }
  var eb=$("#errBox");
  eb.innerHTML = (S.status && !S.status.ok && S.status.error) ? '<div class="err">⚠️ Мониторинг: '+esc(S.status.error)+'. Пробуем снова…</div>' : "";
  if(!me) return;
  var box=$("#filters");
  if(!S.filters.length){
    box.innerHTML='<div class="glass empty"><div class="ill"></div><h3>Создайте первый фильтр</h3><p>Укажите, сколько USDT нужно купить и по какому курсу — я пришлю объявление в ту же секунду, как оно появится.</p><button class="btn p" data-act="new-filter">＋ Создать фильтр</button></div>';
    return;
  }
  box.innerHTML = S.filters.map(fcard).join("");
}
function fcard(f){
  var s=sign(f.fiat), mk=S.market[f.fiat];
  var ms = mk ? mk.ads.filter(function(a){return matches(a,f);}) : null;
  var cnt = ms ? ms.length : f.matchCount, best = ms ? (ms[0]&&ms[0].price) : f.best;
  var pays = (f.payments||[]).map(function(p){return payName(f.fiat,p);});
  var chips = pays.length ? pays.slice(0,3).map(function(p){return '<span class="chip">'+esc(p)+'</span>';}).join("")+(pays.length>3?'<span class="chip dim">+'+(pays.length-3)+'</span>':"") : '<span class="chip dim">Любой способ оплаты</span>';
  var extra=[]; if(f.min_rate) extra.push("от "+f.min_rate+"%"); if(f.min_orders) extra.push("от "+f.min_orders+" сделок"); if(f.only_online) extra.push("онлайн"); if(f.only_verified) extra.push("✔ мерчанты");
  return '<div class="glass fcard" style="'+(f.active?"":"opacity:.62")+'">'+
    '<div class="fhead"><b>'+esc(f.name)+'</b><span class="badge">'+f.fiat+'</span><button class="sw '+(f.active?"on":"")+'" data-act="toggle-filter" data-id="'+f.id+'"></button></div>'+
    '<div class="grid2"><div class="cell"><span>Сумма USDT</span><b>'+range(f.usdt_min,f.usdt_max,"")+'</b></div><div class="cell"><span>Курс, '+s+'</span><b>'+range(f.price_min,f.price_max,"",true)+'</b></div></div>'+
    '<div class="chips">'+chips+extra.map(function(e){return '<span class="chip dim">'+e+'</span>';}).join("")+'</div>'+
    '<div class="ffoot"><div class="match '+(cnt?"hot":"")+'" data-act="show-matches" data-id="'+f.id+'">'+(cnt?'<span class="on-dot"></span>':'')+'Сейчас: <b>'+(cnt==null?"…":cnt)+'</b>'+(best?'<span>· от '+fmt(best)+" "+s+'</span>':"")+'</div>'+
    '<button class="ibtn" data-act="edit-filter" data-id="'+f.id+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20h4L19 9l-4-4L4 16v4z"/></svg></button>'+
    '<button class="ibtn" data-act="del-filter" data-id="'+f.id+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 7h14M10 7V5h4v2M7 7l1 13h8l1-13"/></svg></button></div>'+
  '</div>';
}
function range(a,b,u,price){ var f=price?function(x){return fmt(x);}:fq; if(!a&&!b) return "любая"; if(!b) return "от "+f(a)+u; if(!a) return "до "+f(b)+u; return f(a)+" – "+f(b)+u; }

/* ---------- feed ---------- */
function feedMatches(tag){
  var out=[], seen={};
  S.filters.forEach(function(f){
    if(!f.active && tag==="all") return;
    if(tag!=="all" && String(f.id)!==String(tag)) return;
    var m=S.market[f.fiat]; if(!m) return;
    m.ads.forEach(function(a){ if(!seen[a.id] && matches(a,f)){ seen[a.id]=1; out.push({a:a,f:f}); } });
  });
  out.sort(function(x,y){return x.a.price-y.a.price;});
  return out;
}
function renderFeed(){
  document.querySelectorAll("#feedSeg button").forEach(function(b){ b.classList.toggle("on", b.dataset.seg===S.seg); });
  var tags=$("#feedTags"), box=$("#feed");
  if(S.seg==="match"){
    tags.style.display = S.filters.length>1 ? "flex":"none";
    tags.innerHTML = '<button class="tag '+(S.tag==="all"?"on":"")+'" data-tag="all">Все активные</button>'+S.filters.map(function(f){return '<button class="tag '+(String(S.tag)===String(f.id)?"on":"")+'" data-tag="'+f.id+'">'+esc(f.name)+'</button>';}).join("");
    var list=feedMatches(S.tag);
    if(!S.filters.length){ box.innerHTML='<div class="glass empty"><div class="ill"></div><h3>Нет фильтров</h3><p>Создайте фильтр — здесь появятся подходящие объявления.</p><button class="btn p" data-act="new-filter">＋ Создать фильтр</button></div>'; return; }
    if(!list.length){ box.innerHTML='<div class="glass empty"><div class="ill"></div><h3>Пока ничего не подходит</h3><p>Радар продолжает слушать стакан. Как только появится объявление под ваши условия — пришлю его в чат.</p><button class="btn g" data-seg-go="market">Посмотреть весь стакан</button></div>'; return; }
    box.innerHTML = list.slice(0,80).map(function(x){return adCard(x.a,x.f);}).join("");
  } else if(S.seg==="market"){
    tags.style.display="flex";
    tags.innerHTML = S.fiats.map(function(f){return '<button class="tag '+(S.fiat===f?"on":"")+'" data-fiat="'+f+'">'+f+'</button>';}).join("");
    var m=S.market[S.fiat];
    if(!m){ box.innerHTML='<div class="skel"></div><div class="skel"></div>'; return; }
    if(!m.ads.length){ box.innerHTML='<div class="glass empty"><h3>Пусто</h3><p>'+esc(m.error||"Объявлений нет")+'</p></div>'; return; }
    box.innerHTML = m.ads.slice(0,60).map(function(a){return adCard(a,null);}).join("");
  } else {
    tags.style.display="none";
    if(!S.hits.length){ box.innerHTML='<div class="glass empty"><div class="ill"></div><h3>Уведомлений ещё не было</h3><p>Здесь сохраняются все объявления, которые бот присылал вам за неделю.</p></div>'; return; }
    box.innerHTML = S.hits.map(function(h){return adCard(h.ad,null,h);}).join("");
  }
}
function adCard(a,f,h){
  var s=sign(a.fiat);
  var bmin=Math.max(a.minUsdt,(f&&f.usdt_min)||0), bmax=Math.min(a.maxUsdt,(f&&f.usdt_max)||Infinity);
  var pays=a.payments.map(function(p){return '<span class="chip">'+esc(payName(a.fiat,p))+'</span>';}).join("");
  var req=[]; if(a.req){ if(a.req.regDays) req.push("аккаунт от "+a.req.regDays+" дн."); if(a.req.orders30) req.push("от "+a.req.orders30+" сделок/30д"); if(a.req.rate30) req.push("от "+a.req.rate30+"% завершения"); }
  return '<div class="glass ad">'+
    '<div class="adtop"><div class="adprice">'+fmt(a.price)+'<small>'+s+'</small></div>'+
      '<div class="adwho"><b>'+(a.online?'<span class="on-dot"></span>':'<span class="off-dot"></span>')+esc(a.nick)+(a.verified?' <span class="ver">✓</span>':'')+'</b>'+a.rate+'% · '+fq(a.orders)+' сделок</div></div>'+
    '<div class="adrows">'+
      '<div><span>Можно купить</span><b>'+fq(bmin)+' – '+fq(bmax)+' USDT</b></div>'+
      '<div><span>Лимит</span><b>'+fq(a.minFiat)+' – '+fq(a.maxFiat)+' '+s+'</b></div>'+
      '<div><span>Доступно</span><b>'+fq(a.qty)+' USDT</b></div>'+
      (a.period?'<div><span>Время на оплату</span><b>'+a.period+' мин</b></div>':'')+
    '</div>'+
    '<div class="chips">'+pays+'</div>'+
    (req.length?'<div class="req">⚠️ <span>'+esc(req.join(" · "))+'</span></div>':'')+
    (a.remark?'<div class="remark" data-act="remark">'+esc(a.remark)+'</div>':'')+
    '<div class="adact"><button class="btn p w" data-act="open" data-url="'+esc(a.url)+'">⚡ Открыть в Bybit</button>'+
      '<button class="ibtn" style="width:48px;height:48px;border-radius:16px" data-act="hide" data-id="'+esc(a.maskId)+'" data-nick="'+esc(a.nick)+'" title="Скрыть продавца"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3l18 18M10.6 6.1A9.7 9.7 0 0 1 12 6c5 0 9 6 9 6a17 17 0 0 1-2.6 3.2M6.3 6.4C4.1 8 3 12 3 12s4 6 9 6a8.8 8.8 0 0 0 4.2-1"/></svg></button></div>'+
    (h?'<div class="meta"><span>🎯 '+esc(h.filter||"")+'</span><span>'+ago(h.at)+'</span></div>':(f?'<div class="meta"><span>🎯 '+esc(f.name)+'</span><span></span></div>':''))+
  '</div>';
}

/* ---------- settings ---------- */
function renderSettings(){
  var me=S.me; if(!me) return;
  $("#swMon").classList.toggle("on", !me.paused);
  $("#swSil").classList.toggle("on", !!me.silent);
  $("#monTxt").textContent = me.paused ? "Выключен — уведомления не приходят" : "Проверка стакана каждые "+S.poll+" сек";
  $("#pauseTxt").textContent = me.pauseUntil ? "На паузе до "+new Date(me.pauseUntil).toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}) : "Временно не присылать";
  var bl=me.blacklist||[];
  $("#blList").innerHTML = bl.length ? bl.map(function(b){return '<div class="srow"><div class="ic">🙈</div><div class="tx"><b>'+esc(b.nick)+'</b><small>Не показывается в уведомлениях</small></div><button class="btn g sm" data-act="unhide" data-id="'+esc(b.id)+'">Вернуть</button></div>';}).join("") : '<div class="note">Пока никого. Скрыть продавца можно кнопкой 🙈 в объявлении.</div>';
  $("#about").innerHTML = '<b>P2P Radar '+esc(S.version||"")+'</b><br>Бот: @'+esc(S.bot||"—")+' · опрос каждые '+S.poll+' с'+(S.status?'<br>Последняя проверка: '+ago(S.status.lastTick)+' · уведомлений отправлено: '+S.status.sent:'')+'<br><br>Данные — публичный стакан Bybit P2P. Сервис не связан с Bybit.';
}

/* ---------- filter editor ---------- */
var E=null;
function openEditor(f){
  var fiat=(f&&f.fiat)||S.fiat;
  E = f ? JSON.parse(JSON.stringify(f)) : { id:0, name:"Фильтр "+(S.filters.length+1), fiat:fiat, usdt_min:"", usdt_max:"", price_min:"", price_max:"", payments:[], min_rate:0, min_orders:0, only_online:0, only_verified:0 };
  ["usdt_min","usdt_max","price_min","price_max"].forEach(function(k){ if(!E[k]) E[k]=""; });
  E.showAllPays=false;
  renderEditor();
  $("#ov").classList.add("on"); $("#sheet").classList.add("on");
  try{ tg && tg.BackButton.show(); }catch(e){}
  haptic("light");
  if(!S.market[E.fiat]) loadMarket(E.fiat).then(function(){ if(E) renderEditor(true); });
}
function closeSheet(){ $("#ov").classList.remove("on"); $("#sheet").classList.remove("on"); E=null; try{ if(S.tab==="radar") tg && tg.BackButton.hide(); }catch(e){} }
function renderEditor(keepScroll){
  var sh=$("#sheet"), st=sh.scrollTop, m=S.market[E.fiat], s=sign(E.fiat);
  var best = m&&m.ads[0] ? m.ads[0].price : 0;
  var pays = m ? m.payments : [];
  var shown = E.showAllPays ? pays : pays.slice(0,12);
  E.payments.forEach(function(id){ if(!shown.some(function(p){return p.id===id;})){ var p=pays.filter(function(x){return x.id===id;})[0]; shown=shown.concat([p||{id:id,name:"#"+id,count:0}]); } });
  var q=function(arr,key){ return arr.map(function(o){ return '<button data-q="'+key+'" data-v="'+o[0]+'" class="'+(String(E[key])===String(o[0])?"on":"")+'">'+o[1]+'</button>'; }).join(""); };
  sh.innerHTML =
    '<div class="grab"></div><h3>'+(E.id?"Изменить фильтр":"Новый фильтр")+'</h3><div class="hint" style="margin:0">Пришлю объявление, как только оно подойдёт под эти условия</div>'+
    '<div class="field"><label>Название</label><input class="inp" id="eName" maxlength="40" value="'+esc(E.name)+'"></div>'+
    '<div class="field"><label>Валюта оплаты</label><div class="hscroll" style="padding-bottom:0">'+S.fiats.map(function(f){return '<button class="tag '+(E.fiat===f?"on":"")+'" data-efiat="'+f+'">'+f+'</button>';}).join("")+'</div></div>'+
    '<div class="field"><label>Сколько USDT купить</label><div class="pair"><div class="w"><input class="inp" inputmode="decimal" data-k="usdt_min" placeholder="от" value="'+E.usdt_min+'"><em>USDT</em></div><i>—</i><div class="w"><input class="inp" inputmode="decimal" data-k="usdt_max" placeholder="до" value="'+E.usdt_max+'"><em>USDT</em></div></div>'+
      '<div class="quick">'+[["100","до 100"],["500","100–500"],["2000","500–2 000"],["10000","2 000–10 000"]].map(function(o,i){var mins=[0,100,500,2000];return '<button data-usdt="'+mins[i]+'-'+o[0]+'">'+o[1]+'</button>';}).join("")+'</div>'+
      '<div class="hint">Подойдут объявления, где можно купить хотя бы часть этого диапазона.</div></div>'+
    '<div class="field"><label>Курс за 1 USDT</label><div class="pair"><div class="w"><input class="inp" inputmode="decimal" data-k="price_min" placeholder="от" value="'+E.price_min+'"><em>'+s+'</em></div><i>—</i><div class="w"><input class="inp" inputmode="decimal" data-k="price_max" placeholder="до" value="'+E.price_max+'"><em>'+s+'</em></div></div>'+
      (best?'<div class="hint">Лучший сейчас: <b>'+fmt(best)+' '+s+'</b></div><div class="quick"><button data-pmax="0">≤ '+fmt(best)+'</button><button data-pmax="0.3">+0,3%</button><button data-pmax="0.7">+0,7%</button><button data-pmax="1.5">+1,5%</button></div>':'<div class="hint">Загружаем текущий курс…</div>')+'</div>'+
    '<div class="field"><label>Способ оплаты '+(E.payments.length?'<span style="text-transform:none;letter-spacing:0">· выбрано '+E.payments.length+'</span>':'<span style="text-transform:none;letter-spacing:0">· любой</span>')+'</label><div class="chips">'+
      shown.map(function(p){return '<button class="pchip '+(E.payments.indexOf(p.id)>=0?"on":"")+'" data-pay="'+p.id+'">'+esc(p.name)+(p.count?'<small>'+p.count+'</small>':'')+'</button>';}).join("")+
      (pays.length>12&&!E.showAllPays?'<button class="pchip" data-act="all-pays">Все ('+pays.length+') ›</button>':'')+
      (E.payments.length?'<button class="pchip" data-act="clear-pays">✕ Сбросить</button>':'')+
    '</div></div>'+
    '<div class="field"><label>Надёжность продавца</label>'+
      '<div class="hint" style="margin-top:0">Завершённых сделок, %</div><div class="quick">'+q([[0,"любой"],[90,"от 90%"],[95,"от 95%"],[98,"от 98%"]],"min_rate")+'</div>'+
      '<div class="hint">Сделок за 30 дней</div><div class="quick">'+q([[0,"любое"],[20,"от 20"],[100,"от 100"],[500,"от 500"]],"min_orders")+'</div>'+
      '<div class="trow"><div><b>Только онлайн</b><small>Продавец сейчас в сети</small></div><button class="sw '+(E.only_online?"on":"")+'" data-tog="only_online"></button></div>'+
      '<div class="trow" style="padding-top:0"><div><b>Только верифицированные</b><small>Мерчанты с галочкой Bybit</small></div><button class="sw '+(E.only_verified?"on":"")+'" data-tog="only_verified"></button></div>'+
    '</div>'+
    '<div id="ePrev"></div>'+
    '<div class="acts">'+(E.id?'<button class="btn g danger" data-act="del-filter" data-id="'+E.id+'">Удалить</button>':'<button class="btn g" data-act="close-sheet">Отмена</button>')+'<button class="btn p w" data-act="save-filter">'+(E.id?"Сохранить":"Запустить радар")+'</button></div>';
  renderPreview();
  if(keepScroll) sh.scrollTop=st;
}
function editorFilter(){ return { fiat:E.fiat, usdt_min:num(E.usdt_min), usdt_max:num(E.usdt_max), price_min:num(E.price_min), price_max:num(E.price_max), payments:E.payments, min_rate:+E.min_rate, min_orders:+E.min_orders, only_online:E.only_online, only_verified:E.only_verified }; }
function renderPreview(){
  var el=$("#ePrev"); if(!el||!E) return;
  var m=S.market[E.fiat]; if(!m){ el.innerHTML=""; return; }
  var f=editorFilter(), ms=m.ads.filter(function(a){return matches(a,f);});
  el.innerHTML='<div class="preview '+(ms.length?"":"zero")+'"><b>'+ms.length+'</b><span>'+(ms.length?'подходит прямо сейчас · лучший <b style="font-size:13px;color:var(--text)">'+fmt(ms[0].price)+' '+sign(E.fiat)+'</b><br>Их пришлю сразу после запуска':'сейчас не подходит ни одно — пришлю, как только появится')+'</span></div>';
}
function saveFilter(){
  var body=editorFilter(); body.id=E.id; body.name=($("#eName").value||"").trim()||"Фильтр";
  if(!body.price_max && !body.price_min){ toast("Укажите курс — хотя бы «до»","warning"); return; }
  api("/api/filters",{method:"POST",body:body}).then(function(){ toast(E&&E.id?"✅ Фильтр обновлён":"📡 Радар запущен","ok"); S.fiat=body.fiat; S.fiatTouched=true; closeSheet(); refresh(); }).catch(onErr);
}

/* ---------- navigation ---------- */
function go(tab){
  S.tab=tab;
  document.querySelectorAll(".view").forEach(function(v){ v.classList.toggle("on", v.id==="v-"+tab); });
  document.querySelectorAll(".tabbar button").forEach(function(b){ b.classList.toggle("on", b.dataset.tab===tab); });
  try{ if(tab==="radar") tg.BackButton.hide(); else tg.BackButton.show(); }catch(e){}
  if(tab==="feed"){ renderFeed(); loadHits(); }
  window.scrollTo({top:0,behavior:"smooth"});
}

/* ---------- events ---------- */
document.addEventListener("click", function(ev){
  var t=ev.target.closest("[data-act],[data-tab],[data-seg],[data-seg-go],[data-tag],[data-fiat],[data-efiat],[data-pay],[data-q],[data-tog],[data-usdt],[data-pmax]");
  if(!t) return;
  var d=t.dataset;
  if(d.tab){ haptic("sel"); go(d.tab); return; }
  if(d.seg||d.segGo){ haptic("sel"); S.seg=d.seg||d.segGo; if(S.seg==="hist") loadHits(); if(S.seg==="market"&&!S.market[S.fiat]) loadMarket(); renderFeed(); return; }
  if(d.tag){ haptic("sel"); S.tag=d.tag; renderFeed(); return; }
  if(d.fiat){ haptic("sel"); S.fiat=d.fiat; S.fiatTouched=true; renderFeed(); loadMarket(d.fiat); return; }
  if(E){
    if(d.efiat){ haptic("sel"); E.fiat=d.efiat; E.payments=[]; E.price_min=""; E.price_max=""; renderEditor(true); if(!S.market[E.fiat]) loadMarket(E.fiat).then(function(){ if(E) renderEditor(true); }); return; }
    if(d.pay){ haptic("sel"); var i=E.payments.indexOf(d.pay); if(i>=0) E.payments.splice(i,1); else E.payments.push(d.pay); renderEditor(true); return; }
    if(d.q){ haptic("sel"); E[d.q]=+d.v; renderEditor(true); return; }
    if(d.tog){ haptic("sel"); E[d.tog]=E[d.tog]?0:1; renderEditor(true); return; }
    if(d.usdt){ haptic("sel"); var p=d.usdt.split("-"); E.usdt_min=+p[0]||""; E.usdt_max=+p[1]||""; renderEditor(true); return; }
    if(d.pmax!=null){ haptic("sel"); var m=S.market[E.fiat]; if(m&&m.ads[0]){ var b=m.ads[0].price; E.price_max=(Math.round(b*(1+(+d.pmax)/100)*100)/100).toFixed(2); renderEditor(true);} return; }
  }
  switch(d.act){
    case "new-filter": openEditor(null); break;
    case "edit-filter": openEditor(S.filters.filter(function(f){return f.id==d.id;})[0]); break;
    case "close-sheet": closeSheet(); break;
    case "save-filter": saveFilter(); break;
    case "all-pays": E.showAllPays=true; renderEditor(true); break;
    case "clear-pays": E.payments=[]; renderEditor(true); break;
    case "del-filter": confirmBox("Удалить этот фильтр?", function(ok){ if(!ok) return; api("/api/filters/"+d.id,{method:"DELETE"}).then(function(){ toast("🗑 Фильтр удалён","ok"); closeSheet(); refresh(); }).catch(onErr); }); break;
    case "toggle-filter": haptic("medium"); t.classList.toggle("on"); api("/api/filters/"+d.id+"/toggle",{method:"POST",body:{}}).then(refresh).catch(onErr); break;
    case "show-matches": haptic("sel"); S.seg="match"; S.tag=d.id; go("feed"); break;
    case "open": openUrl(d.url); break;
    case "open-list": var mk=S.market[S.fiat]; openUrl(mk?mk.listUrl:"https://www.bybit.com/fiat/trade/otc/buy/USDT/"+S.fiat); break;
    case "hide": confirmBox("Скрыть продавца «"+d.nick+"»? Его объявления больше не будут приходить.", function(ok){ if(!ok) return; api("/api/blacklist",{method:"POST",body:{id:d.id,nick:d.nick}}).then(function(){ toast("🙈 Продавец скрыт","ok"); return loadState(); }).then(renderFeed).catch(onErr); }); break;
    case "unhide": api("/api/blacklist",{method:"POST",body:{id:d.id,remove:true}}).then(function(){ toast("Продавец возвращён","ok"); return loadState(); }).catch(onErr); break;
    case "toggle-monitor": case "set-paused": var on=!(S.me.paused||S.me.pauseUntil); haptic("medium"); api("/api/settings",{method:"POST",body:{paused:on}}).then(function(){ toast(on?"⏸ Мониторинг на паузе":"▶️ Мониторинг включён","ok"); return loadState(); }).catch(onErr); break;
    case "set-silent": api("/api/settings",{method:"POST",body:{silent:!S.me.silent}}).then(function(){ haptic("sel"); return loadState(); }).catch(onErr); break;
    case "pause": api("/api/settings",{method:"POST",body:{pauseMinutes:+d.min}}).then(function(){ toast("⏸ Пауза на "+(d.min/60)+" ч","ok"); return loadState(); }).catch(onErr); break;
    case "test": api("/api/test",{method:"POST",body:{}}).then(function(){ toast("📨 Отправил в чат с ботом","ok"); }).catch(onErr); break;
    case "remark": t.classList.toggle("open"); break;
  }
});
document.addEventListener("input", function(ev){
  if(!E) return;
  var k=ev.target.dataset && ev.target.dataset.k;
  if(k){ E[k]=ev.target.value.replace(",","."); renderPreview(); }
  if(ev.target.id==="eName") E.name=ev.target.value;
});
$("#fiatSel").addEventListener("change", function(e){ haptic("sel"); S.fiat=e.target.value; S.fiatTouched=true; renderRadar(); loadMarket(S.fiat); api("/api/settings",{method:"POST",body:{fiat:S.fiat}}).catch(function(){}); });

/* ---------- start ---------- */
tgInit();
if(location.hash==="#feed") go("feed");
refresh();
setInterval(function(){ if(document.hidden) return; loadMarket(S.fiat).catch(function(){}); }, 8000);
setInterval(function(){ if(document.hidden) return; loadState().catch(function(){}); if(S.tab==="feed"&&S.seg==="hist") loadHits().catch(function(){}); }, 20000);
document.addEventListener("visibilitychange", function(){ if(!document.hidden) refresh(); });
})();
</script>
</body>
</html>
`;
const LOGO_SVG: string = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
<defs>
<linearGradient id="a" gradientUnits="userSpaceOnUse" x1="17.2" y1="8.3" x2="54.1" y2="14.8">
<stop offset="0" stop-color="#FF4D6D" stop-opacity="0"/>
<stop offset=".55" stop-color="#FF7A2F" stop-opacity=".45"/>
<stop offset="1" stop-color="#FFC24B" stop-opacity=".9"/>
</linearGradient>
<linearGradient id="r" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="#fff" stop-opacity=".7"/>
<stop offset=".5" stop-color="#fff" stop-opacity=".18"/>
<stop offset="1" stop-color="#fff" stop-opacity=".45"/>
</linearGradient>
<filter id="g" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="1.6"/></filter>
</defs>
<circle cx="32" cy="32" r="29" fill="#1C1236" fill-opacity=".85"/>
<circle cx="32" cy="32" r="29" fill="#fff" fill-opacity=".06"/>
<g fill="none" stroke="#fff" stroke-opacity=".18" stroke-width="1.2"><circle cx="32" cy="32" r="20"/><circle cx="32" cy="32" r="11"/></g>
<path d="M32 32L17.2 8.3A28 28 0 0 1 54.1 14.8Z" fill="url(#a)"/>
<path d="M32 32L54.1 14.8" stroke="#FFC24B" stroke-width="2" stroke-linecap="round"/>
<circle cx="32" cy="32" r="28.25" fill="none" stroke="url(#r)" stroke-width="1.5"/>
<circle cx="40.9" cy="18.7" r="5" fill="#34E3A4" opacity=".7" filter="url(#g)"/>
<circle cx="40.9" cy="18.7" r="3.2" fill="#34E3A4"/>
<circle cx="32" cy="32" r="3" fill="#FF7A2F"/>
</svg>`;

// ───────────── Настройки (переменные окружения Railway) ─────────────
const env = Bun.env;
const VERSION = "1.0.0";
const BOT_TOKEN = (env.BOT_TOKEN || "").trim();
const PORT = Number(env.PORT || 3000);
const DATA_DIR = env.DATA_DIR || env.RAILWAY_VOLUME_MOUNT_PATH || "./data";
const WEBAPP_URL = (env.WEBAPP_URL || (env.RAILWAY_PUBLIC_DOMAIN ? `https://${env.RAILWAY_PUBLIC_DOMAIN}` : "")).replace(/\/$/, "");
const POLL_MS = Math.max(3, Number(env.POLL_SECONDS || 6)) * 1000;
const MAX_PAGES = Math.min(10, Math.max(1, Number(env.MAX_PAGES || 4)));
const PAGE_SIZE = 50;
const PROXY_URL = env.PROXY_URL || "";
const DEV = env.DEV === "1";
const ALLOWED = (env.ALLOWED_USERS || "").split(/[\s,;]+/).filter(Boolean).map(Number);
const MAX_PER_TICK = 5; // сколько карточек максимум отправлять за один цикл на фильтр
const REAPPEAR_MS = 30 * 60 * 1000; // объявление «вернулось» спустя 30 мин → уведомим снова
const FIATS = ["RUB", "KZT", "UAH", "BYN", "USD", "EUR", "UZS", "KGS", "GEL", "TRY", "AZN", "AMD"];
const FIAT_SIGN: Record<string, string> = { RUB: "₽", KZT: "₸", UAH: "₴", BYN: "Br", USD: "$", EUR: "€", UZS: "сўм", KGS: "сом", GEL: "₾", TRY: "₺", AZN: "₼", AMD: "֏" };

const log = (...a: any[]) => console.log(new Date().toISOString().slice(11, 19), ...a);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ───────────── База данных (SQLite на томе /data) ─────────────
mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(`${DATA_DIR}/radar.db`, { create: true });
db.exec("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=3000;");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT, username TEXT,
  paused INTEGER DEFAULT 0, silent INTEGER DEFAULT 0, pause_until INTEGER DEFAULT 0,
  blacklist TEXT DEFAULT '[]', fiat TEXT DEFAULT 'RUB', created_at INTEGER);
CREATE TABLE IF NOT EXISTS filters(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT, fiat TEXT,
  usdt_min REAL, usdt_max REAL, price_min REAL, price_max REAL, payments TEXT DEFAULT '[]',
  min_rate INTEGER DEFAULT 0, min_orders INTEGER DEFAULT 0, only_online INTEGER DEFAULT 0,
  only_verified INTEGER DEFAULT 0, active INTEGER DEFAULT 1, created_at INTEGER);
CREATE TABLE IF NOT EXISTS seen(
  filter_id INTEGER, ad_id TEXT, price REAL, notified_at INTEGER, last_match INTEGER,
  PRIMARY KEY(filter_id, ad_id));
CREATE TABLE IF NOT EXISTS hits(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, filter_id INTEGER, filter_name TEXT,
  ad TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS hits_user ON hits(user_id, id);
`);

type User = { id: number; name: string; username: string; paused: number; silent: number; pause_until: number; blacklist: string; fiat: string; created_at: number };
type Filter = {
  id: number; user_id: number; name: string; fiat: string; usdt_min: number; usdt_max: number;
  price_min: number; price_max: number; payments: string[]; min_rate: number; min_orders: number;
  only_online: number; only_verified: number; active: number; created_at: number;
};
type Ad = {
  id: string; maskId: string; nick: string; fiat: string; price: number; minFiat: number; maxFiat: number;
  qty: number; minUsdt: number; maxUsdt: number; payments: string[]; orders: number; rate: number;
  online: boolean; verified: boolean; tags: string[]; period: number;
  req: { kyc: boolean; regDays: number; orders30: number; rate30: number }; remark: string;
};

const q = {
  user: db.query<User, [number]>("SELECT * FROM users WHERE id=?"),
  upsertUser: db.query("INSERT INTO users(id,name,username,created_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, username=excluded.username"),
  filtersOf: db.query<any, [number]>("SELECT * FROM filters WHERE user_id=? ORDER BY id"),
  filter: db.query<any, [number, number]>("SELECT * FROM filters WHERE id=? AND user_id=?"),
  activeFilters: db.query<any, [number]>(
    "SELECT f.* FROM filters f JOIN users u ON u.id=f.user_id WHERE f.active=1 AND u.paused=0 AND u.pause_until<?"),
  seenGet: db.query<{ price: number; notified_at: number; last_match: number }, [number, string]>(
    "SELECT price,notified_at,last_match FROM seen WHERE filter_id=? AND ad_id=?"),
  seenPut: db.query("INSERT INTO seen(filter_id,ad_id,price,notified_at,last_match) VALUES(?,?,?,?,?) ON CONFLICT(filter_id,ad_id) DO UPDATE SET price=excluded.price, notified_at=excluded.notified_at, last_match=excluded.last_match"),
  seenClearFilter: db.query("DELETE FROM seen WHERE filter_id=?"),
  seenGc: db.query("DELETE FROM seen WHERE last_match<?"),
  hitAdd: db.query("INSERT INTO hits(user_id,filter_id,filter_name,ad,created_at) VALUES(?,?,?,?,?)"),
  hitsOf: db.query<any, [number]>("SELECT * FROM hits WHERE user_id=? ORDER BY id DESC LIMIT 60"),
  hitsGc: db.query("DELETE FROM hits WHERE created_at<?"),
};

const parseFilter = (r: any): Filter => ({ ...r, payments: safeJson(r.payments, []) });
function safeJson<T>(s: string, d: T): T { try { return JSON.parse(s) ?? d; } catch { return d; } }
function ensureUser(u: { id: number; first_name?: string; last_name?: string; username?: string }) {
  const name = [u.first_name, u.last_name].filter(Boolean).join(" ") || "друг";
  q.upsertUser.run(u.id, name, u.username || "", Date.now());
  return q.user.get(u.id)!;
}
const blacklistOf = (u: User | null): { id: string; nick: string }[] => (u ? safeJson(u.blacklist, []) : []);

// ───────────── Bybit P2P ─────────────
const BYBIT_HEADERS = {
  "content-type": "application/json;charset=UTF-8",
  accept: "application/json",
  "accept-language": "ru-RU,ru;q=0.9,en;q=0.8",
  origin: "https://www.bybit.com",
  referer: "https://www.bybit.com/",
  "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36",
};
const fetchOpts = (o: RequestInit): RequestInit => (PROXY_URL ? ({ ...o, proxy: PROXY_URL } as any) : o);

function norm(x: any, fiat: string): Ad | null {
  const price = +x.price;
  if (!(price > 0)) return null;
  if (x.side !== undefined && +x.side !== 1) return null; // нужны только объявления «продавец продаёт USDT»
  const minFiat = +x.minAmount || 0, maxFiat = +x.maxAmount || 0, qty = +x.lastQuantity || 0;
  const tp = x.tradingPreferenceSet || {};
  const tags: string[] = Array.isArray(x.authTag) ? x.authTag.map(String) : [];
  return {
    id: String(x.id), maskId: String(x.userMaskId || ""), nick: String(x.nickName || "—"), fiat, price,
    minFiat, maxFiat, qty, minUsdt: minFiat / price, maxUsdt: Math.min(maxFiat / price, qty),
    payments: (x.payments || []).map(String), orders: +x.recentOrderNum || 0, rate: +x.recentExecuteRate || 0,
    online: !!x.isOnline, verified: tags.includes("VA") || tags.includes("BA"), tags, period: +x.paymentPeriod || 0,
    req: {
      kyc: !!tp.isKyc,
      regDays: tp.hasRegisterTime ? +tp.registerTimeThreshold || 0 : 0,
      orders30: tp.hasOrderFinishNumberDay30 ? +tp.orderFinishNumberDay30 || 0 : 0,
      rate30: tp.hasCompleteRateDay30 ? +tp.completeRateDay30 || 0 : 0,
    },
    remark: String(x.remark || "").slice(0, 500),
  };
}

async function bybitPage(fiat: string, page: number) {
  const body = { userId: "", tokenId: "USDT", currencyId: fiat, payment: [], side: "1", size: String(PAGE_SIZE), page: String(page), amount: "", authMaker: false, canTrade: false };
  const r = await fetch("https://api2.bybit.com/fiat/otc/item/online",
    fetchOpts({ method: "POST", headers: BYBIT_HEADERS, body: JSON.stringify(body), signal: AbortSignal.timeout(12000) }));
  if (!r.ok) throw new Error(`Bybit HTTP ${r.status}`);
  const j: any = await r.json();
  if (j.ret_code !== 0) throw new Error(`Bybit: ${j.ret_msg}`);
  return { items: (j.result?.items || []) as any[], count: +j.result?.count || 0 };
}

type Market = { fiat: string; ads: Ad[]; total: number; at: number; error: string };
const markets = new Map<string, Market>();
const marketWanted = new Map<string, number>(); // валюты, которые недавно смотрели в приложении

async function loadMarket(fiat: string, priceCap = Infinity): Promise<Market> {
  const ads: Ad[] = [];
  let total = 0;
  try {
    for (let p = 1; p <= MAX_PAGES; p++) {
      const { items, count } = await bybitPage(fiat, p);
      total = count;
      for (const it of items) { const a = norm(it, fiat); if (a) ads.push(a); }
      if (items.length < PAGE_SIZE) break;
      const last = ads[ads.length - 1];
      if (!last || last.price > priceCap) break; // дальше только дороже — не нужно
    }
    ads.sort((a, b) => a.price - b.price);
    const m = { fiat, ads, total, at: Date.now(), error: "" };
    markets.set(fiat, m);
    return m;
  } catch (e: any) {
    const prev = markets.get(fiat);
    const m = { fiat, ads: prev?.ads || [], total: prev?.total || 0, at: prev?.at || 0, error: String(e?.message || e) };
    markets.set(fiat, m);
    log("bybit error", fiat, m.error);
    return m;
  }
}

// Названия способов оплаты (Тинькофф, СБП…) — берём у Bybit, обновляем раз в 6 часов
const payNames = new Map<string, string>();
const fiatPays = new Map<string, string[]>();
const PAY_RU: Record<string, string> = {
  Tinkoff: "Т-Банк", "T-Bank": "Т-Банк", Sberbank: "Сбербанк", SBP: "СБП", "SBP - Fast Bank Transfer": "СБП",
  Raiffeisenbank: "Райффайзен", "Alfa Bank": "Альфа-Банк", "Alfa-Bank": "Альфа-Банк", VTB: "ВТБ", "VTB Bank": "ВТБ",
  "Bank Transfer": "Банковский перевод", Cash: "Наличные", "Cash Deposit to Bank": "Внесение наличных",
  "Gazprombank": "Газпромбанк", "Rosbank": "Росбанк", "Ozon Bank": "Озон Банк", "Yandex Pay": "Яндекс Пэй",
  "MTS Bank": "МТС Банк", "Pochta Bank": "Почта Банк", "Sovcombank": "Совкомбанк", "Home Credit Bank": "Хоум Банк",
  "Russian Standard Bank": "Русский Стандарт", "Otkritie": "Открытие", "Uralsib": "Уралсиб", "Mir": "МИР",
  "QIWI": "QIWI", "YooMoney": "ЮMoney", "Kaspi Bank": "Kaspi", "Monobank": "Monobank", "PrivatBank": "ПриватБанк",
};
async function loadPayments() {
  try {
    const r = await fetch("https://api2.bybit.com/fiat/otc/configuration/queryAllPaymentList",
      fetchOpts({ method: "POST", headers: BYBIT_HEADERS, body: "{}", signal: AbortSignal.timeout(20000) }));
    const j: any = await r.json();
    for (const p of j?.result?.paymentConfigVo || []) {
      const name = String(p.paymentName || "").trim();
      if (name) payNames.set(String(p.paymentType), PAY_RU[name] || name);
    }
    const map = safeJson<Record<string, number[]>>(j?.result?.currencyPaymentIdMap || "{}", {});
    for (const [fiat, ids] of Object.entries(map)) fiatPays.set(fiat, ids.map(String));
    log(`payments loaded: ${payNames.size}`);
  } catch (e: any) { log("payments error", e?.message || e); }
}
const payName = (id: string) => payNames.get(id) || `Метод #${id}`;

// ───────────── Подбор объявлений под фильтр ─────────────
function matches(a: Ad, f: Filter, bl: { id: string }[]) {
  if (a.fiat !== f.fiat) return false;
  if (f.price_min && a.price < f.price_min) return false;
  if (f.price_max && a.price > f.price_max) return false;
  if (a.maxUsdt + 1e-9 < a.minUsdt) return false; // у продавца осталось меньше, чем его же минимальный лимит
  if (f.usdt_max && a.minUsdt > f.usdt_max + 1e-9) return false; // минимум продавца больше вашего максимума
  if (f.usdt_min && a.maxUsdt + 1e-9 < f.usdt_min) return false; // у продавца нельзя купить даже ваш минимум
  if (f.payments.length && !a.payments.some((p) => f.payments.includes(p))) return false;
  if (f.min_rate && a.rate < f.min_rate) return false;
  if (f.min_orders && a.orders < f.min_orders) return false;
  if (f.only_online && !a.online) return false;
  if (f.only_verified && !a.verified) return false;
  if (bl.some((b) => b.id === a.maskId)) return false;
  return true;
}

// ───────────── Ссылки на Bybit ─────────────
const listUrl = (fiat: string) => `https://www.bybit.com/fiat/trade/otc/buy/USDT/${fiat}`;
const adUrl = (a: Ad) => (a.maskId ? `https://www.bybit.com/fiat/trade/otc/profile/${a.maskId}/USDT/${a.fiat}/item` : listUrl(a.fiat));

// ───────────── Telegram Bot API (без библиотек) ─────────────
let botUsername = "";
async function tg(method: string, payload: any = {}, attempt = 0): Promise<any> {
  if (!BOT_TOKEN) throw new Error("BOT_TOKEN не задан");
  const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload),
    signal: AbortSignal.timeout(method === "getUpdates" ? 40000 : 15000),
  });
  const j: any = await r.json().catch(() => ({ ok: false, description: `HTTP ${r.status}` }));
  if (j.ok) return j.result;
  if (j.parameters?.retry_after && attempt < 3) { await sleep((j.parameters.retry_after + 1) * 1000); return tg(method, payload, attempt + 1); }
  const err: any = new Error(`${method}: ${j.description}`);
  err.code = j.error_code;
  throw err;
}

// Очередь отправки, чтобы не упираться в лимиты Telegram
let sendChain = Promise.resolve();
function send(chatId: number, text: string, extra: any = {}) {
  sendChain = sendChain.then(async () => {
    try {
      await tg("sendMessage", { chat_id: chatId, text, parse_mode: "HTML", link_preview_options: { is_disabled: true }, ...extra });
    } catch (e: any) {
      log("send error", chatId, e.message);
      if (e.code === 403) db.query("UPDATE users SET paused=1 WHERE id=?").run(chatId); // пользователь заблокировал бота
    }
    await sleep(70);
  });
  return sendChain;
}

const esc = (s: any) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const fmt = (n: number, d = 2) => n.toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d }).replace(/ /g, " ");
const fmtQ = (n: number) => fmt(n, n >= 1000 ? 0 : 2);
const sign = (f: string) => FIAT_SIGN[f] || f;

function adText(a: Ad, f: Filter | null, title = "Новое объявление") {
  const s = sign(a.fiat);
  const buyMin = Math.max(a.minUsdt, f?.usdt_min || 0), buyMax = Math.min(a.maxUsdt, f?.usdt_max || Infinity);
  const req: string[] = [];
  if (a.req.regDays) req.push(`аккаунт от ${a.req.regDays} дн.`);
  if (a.req.orders30) req.push(`от ${a.req.orders30} сделок/30д`);
  if (a.req.rate30) req.push(`от ${a.req.rate30}% завершения`);
  const lines = [
    `🟢 <b>${esc(title)}</b>${f ? ` · ${esc(f.name)}` : ""}`,
    ``,
    `💵 <b>${fmt(a.price)} ${s}</b> за 1 USDT`,
    `📦 Можно купить: <b>${fmtQ(buyMin)} – ${fmtQ(buyMax)} USDT</b>`,
    `↔️ Лимит: ${fmtQ(a.minFiat)} – ${fmtQ(a.maxFiat)} ${s} · доступно ${fmtQ(a.qty)} USDT`,
    `💳 ${esc(a.payments.map(payName).join(", ") || "—")}`,
    `👤 <b>${esc(a.nick)}</b>${a.verified ? " ✔️" : ""} · ${a.rate}% · ${a.orders} сделок · ${a.online ? "🟢 онлайн" : "⚪️ офлайн"}`,
    a.period ? `⏱ Время на оплату: ${a.period} мин` : "",
    req.length ? `⚠️ Требования: ${esc(req.join(", "))}` : "",
  ];
  return lines.filter((l, i) => l !== "" || i === 1).join("\n");
}
function adKeyboard(a: Ad) {
  const rows: any[] = [[{ text: "⚡ Открыть в Bybit", url: adUrl(a) }]];
  const row2: any[] = [];
  if (WEBAPP_URL) row2.push({ text: "📡 Радар", web_app: { url: WEBAPP_URL } });
  row2.push({ text: "🙈 Скрыть продавца", callback_data: `bl:${a.maskId}`.slice(0, 64) });
  rows.push(row2);
  rows.push([{ text: "⏸ Пауза 1 ч", callback_data: "p60" }, { text: "📋 Весь стакан", url: listUrl(a.fiat) }]);
  return { inline_keyboard: rows };
}

// ───────────── Монитор ─────────────
const status = { lastTick: 0, tickMs: 0, ok: true, error: "", started: Date.now(), sent: 0 };
let ticking = false;

async function tick() {
  if (ticking) return;
  ticking = true;
  const t0 = Date.now();
  try {
    const now = Date.now();
    const filters = q.activeFilters.all(now).map(parseFilter);
    const fiats = new Set<string>(filters.map((f) => f.fiat));
    for (const [f, at] of marketWanted) if (now - at < 120000) fiats.add(f); else marketWanted.delete(f);
    let anyError = "";
    for (const fiat of fiats) {
      const fs = filters.filter((f) => f.fiat === fiat);
      const cap = fs.length && fs.every((f) => f.price_max > 0) ? Math.max(...fs.map((f) => f.price_max)) : Infinity;
      const m = await loadMarket(fiat, fs.length ? cap : Infinity);
      if (m.error) { anyError = m.error; continue; }
      for (const f of fs) await processFilter(f, m.ads);
    }
    status.ok = !anyError;
    status.error = anyError;
  } catch (e: any) {
    status.ok = false; status.error = String(e?.message || e); log("tick error", status.error);
  } finally {
    status.lastTick = Date.now();
    status.tickMs = Date.now() - t0;
    ticking = false;
  }
}

async function processFilter(f: Filter, ads: Ad[]) {
  const u = q.user.get(f.user_id);
  if (!u) return;
  const bl = blacklistOf(u);
  const now = Date.now();
  const fresh: { a: Ad; cheaper: boolean }[] = [];
  for (const a of ads) {
    if (!matches(a, f, bl)) continue;
    const s = q.seenGet.get(f.id, a.id);
    const isNew = !s || now - s.last_match > REAPPEAR_MS;
    const cheaper = !!s && !isNew && a.price < s.price - 1e-9;
    if (isNew || cheaper) fresh.push({ a, cheaper });
    q.seenPut.run(f.id, a.id, isNew || cheaper ? a.price : s!.price, isNew || cheaper ? now : s!.notified_at, now);
  }
  if (!fresh.length) return;
  fresh.sort((x, y) => x.a.price - y.a.price);
  const silent = !!u.silent;
  for (const { a, cheaper } of fresh.slice(0, MAX_PER_TICK)) {
    q.hitAdd.run(u.id, f.id, f.name, JSON.stringify(a), now);
    send(u.id, adText(a, f, cheaper ? "Подешевело" : "Новое объявление"), { reply_markup: adKeyboard(a), disable_notification: silent });
    status.sent++;
  }
  const rest = fresh.length - MAX_PER_TICK;
  if (rest > 0) {
    for (const { a } of fresh.slice(MAX_PER_TICK)) q.hitAdd.run(u.id, f.id, f.name, JSON.stringify(a), now);
    send(u.id, `➕ И ещё <b>${rest}</b> подходящих объявлений по фильтру «${esc(f.name)}». Все — в приложении.`, {
      disable_notification: true,
      reply_markup: WEBAPP_URL ? { inline_keyboard: [[{ text: "📡 Открыть радар", web_app: { url: WEBAPP_URL + "#feed" } }]] } : undefined,
    });
  }
}

async function monitorLoop() {
  let n = 0;
  for (;;) {
    await tick();
    if (++n % 600 === 0) { // уборка примерно раз в час
      q.seenGc.run(Date.now() - 86400000);
      q.hitsGc.run(Date.now() - 7 * 86400000);
    }
    await sleep(POLL_MS);
  }
}

// ───────────── Команды бота ─────────────
const appButton = (text = "📡 Открыть радар") => (WEBAPP_URL ? { inline_keyboard: [[{ text, web_app: { url: WEBAPP_URL } }]] } : undefined);

async function handleUpdate(up: any) {
  if (up.callback_query) return handleCallback(up.callback_query);
  const m = up.message;
  if (!m?.from || m.chat?.type !== "private") return;
  if (ALLOWED.length && !ALLOWED.includes(m.from.id)) {
    return send(m.chat.id, "🔒 Это приватный бот. Доступ только для владельца.");
  }
  const u = ensureUser(m.from);
  const text: string = (m.text || "").trim();
  const cmd = text.split(/[\s@]/)[0].toLowerCase();
  if (cmd === "/start" || cmd === "/app") {
    return send(u.id, [
      `👋 <b>${esc(u.name)}, это P2P Radar</b>`,
      ``,
      `Я слежу за объявлениями <b>Bybit P2P</b> на покупку USDT и присылаю их сразу, как только появляется подходящее.`,
      ``,
      `1️⃣ Откройте радар и задайте фильтр: сколько USDT нужно и по какому курсу`,
      `2️⃣ Я проверяю стакан каждые ${POLL_MS / 1000} сек.`,
      `3️⃣ Пришло объявление → жмите «⚡ Открыть в Bybit» и покупайте`,
    ].join("\n"), { reply_markup: appButton() });
  }
  if (cmd === "/filters") {
    const fs = q.filtersOf.all(u.id).map(parseFilter);
    if (!fs.length) return send(u.id, "Фильтров пока нет. Создайте первый в радаре 👇", { reply_markup: appButton("➕ Создать фильтр") });
    const lines = fs.map((f) => `${f.active ? "🟢" : "⚪️"} <b>${esc(f.name)}</b>\n    ${fmtQ(f.usdt_min)}–${f.usdt_max ? fmtQ(f.usdt_max) : "∞"} USDT · курс ${f.price_min ? fmt(f.price_min) : "0"}–${f.price_max ? fmt(f.price_max) : "∞"} ${sign(f.fiat)}`);
    return send(u.id, `<b>Ваши фильтры</b>\n\n${lines.join("\n")}`, { reply_markup: appButton("✏️ Изменить") });
  }
  if (cmd === "/pause") {
    db.query("UPDATE users SET paused=1 WHERE id=?").run(u.id);
    return send(u.id, "⏸ Уведомления на паузе. Включить: /resume");
  }
  if (cmd === "/resume") {
    db.query("UPDATE users SET paused=0, pause_until=0 WHERE id=?").run(u.id);
    return send(u.id, "▶️ Мониторинг снова работает.");
  }
  if (cmd === "/best") {
    const m = markets.get(u.fiat || "RUB") || (await loadMarket(u.fiat || "RUB"));
    const a = m.ads[0];
    if (!a) return send(u.id, "Не удалось получить стакан Bybit, попробуйте позже.");
    return send(u.id, adText(a, null, "Лучший курс сейчас"), { reply_markup: adKeyboard(a) });
  }
  return send(u.id, [
    `<b>Команды</b>`,
    `/start — открыть радар`,
    `/filters — мои фильтры`,
    `/best — лучшее объявление прямо сейчас`,
    `/pause — пауза уведомлений`,
    `/resume — возобновить`,
  ].join("\n"), { reply_markup: appButton() });
}

async function handleCallback(cq: any) {
  const id = cq.from.id;
  const data: string = cq.data || "";
  const u = q.user.get(id);
  let answer = "Готово";
  if (u && data.startsWith("bl:")) {
    const mask = data.slice(3);
    const bl = blacklistOf(u);
    if (!bl.some((b) => b.id === mask)) {
      const nick = (cq.message?.text || "").match(/👤 ([^\n·]+?)(?: ✔️)? ·/)?.[1]?.trim() || "продавец";
      bl.push({ id: mask, nick });
      db.query("UPDATE users SET blacklist=? WHERE id=?").run(JSON.stringify(bl), id);
    }
    answer = "Продавец скрыт. Вернуть можно в настройках радара.";
  } else if (u && data === "p60") {
    db.query("UPDATE users SET pause_until=? WHERE id=?").run(Date.now() + 3600000, id);
    answer = "⏸ Пауза на 1 час";
  }
  await tg("answerCallbackQuery", { callback_query_id: cq.id, text: answer }).catch(() => {});
}

async function botLoop() {
  if (!BOT_TOKEN) { log("⚠️  BOT_TOKEN не задан — бот не запущен (сайт и API работают)"); return; }
  try {
    const me = await tg("getMe");
    botUsername = me.username;
    log(`bot @${botUsername}`);
    await tg("deleteWebhook", { drop_pending_updates: false });
    await tg("setMyCommands", { commands: [
      { command: "start", description: "Открыть радар" },
      { command: "filters", description: "Мои фильтры" },
      { command: "best", description: "Лучший курс сейчас" },
      { command: "pause", description: "Пауза уведомлений" },
      { command: "resume", description: "Возобновить" },
    ] });
    if (WEBAPP_URL) await tg("setChatMenuButton", { menu_button: { type: "web_app", text: "Радар", web_app: { url: WEBAPP_URL } } });
    await tg("setMyShortDescription", { short_description: "Мгновенные уведомления о выгодных объявлениях Bybit P2P на покупку USDT." }).catch(() => {});
    await tg("setMyDescription", { description: "📡 P2P Radar следит за стаканом Bybit P2P и сразу присылает объявления на покупку USDT под ваш курс и сумму. Нажмите «Старт», чтобы настроить фильтр." }).catch(() => {});
  } catch (e: any) { log("bot setup error", e.message); }
  let offset = 0;
  for (;;) {
    try {
      const ups = await tg("getUpdates", { offset, timeout: 30, allowed_updates: ["message", "callback_query"] });
      for (const up of ups) {
        offset = up.update_id + 1;
        handleUpdate(up).catch((e) => log("update error", e.message));
      }
    } catch (e: any) {
      log("getUpdates", e.message);
      await sleep(e.code === 409 ? 8000 : 3000);
    }
  }
}

// ───────────── Проверка подписи Telegram Mini App ─────────────
function authUser(req: Request): User | null {
  const init = req.headers.get("x-init-data") || "";
  if (!init) return DEV ? ensureUser({ id: 1, first_name: "Dev" }) : null;
  const p = new URLSearchParams(init);
  const hash = p.get("hash");
  if (!hash || !BOT_TOKEN) return null;
  p.delete("hash");
  const dcs = [...p.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)).map(([k, v]) => `${k}=${v}`).join("\n");
  const secret = createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  if (createHmac("sha256", secret).update(dcs).digest("hex") !== hash) return null;
  if (Date.now() / 1000 - Number(p.get("auth_date") || 0) > 7 * 86400) return null;
  const tu = safeJson<any>(p.get("user") || "{}", {});
  if (!tu.id) return null;
  if (ALLOWED.length && !ALLOWED.includes(tu.id)) return null;
  return ensureUser(tu);
}

// ───────────── HTTP API для Mini App ─────────────
const json = (data: any, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const num = (v: any, d = 0) => { const n = Number(String(v ?? "").replace(",", ".").replace(/\s/g, "")); return Number.isFinite(n) && n >= 0 ? n : d; };

function filterOut(f: Filter, bl: { id: string }[]) {
  const m = markets.get(f.fiat);
  const ms = m ? m.ads.filter((a) => matches(a, f, bl)) : [];
  return { ...f, matchCount: ms.length, best: ms[0]?.price || 0 };
}

async function api(req: Request, url: URL): Promise<Response> {
  const u = authUser(req);
  if (!u) return json({ error: ALLOWED.length ? "forbidden" : "unauthorized" }, 401);
  const path = url.pathname;
  const bl = blacklistOf(u);

  if (path === "/api/state") {
    return json({
      user: { id: u.id, name: u.name, paused: !!u.paused, silent: !!u.silent, pauseUntil: u.pause_until > Date.now() ? u.pause_until : 0, fiat: u.fiat, blacklist: bl },
      filters: q.filtersOf.all(u.id).map(parseFilter).map((f) => filterOut(f, bl)),
      bot: botUsername, poll: POLL_MS / 1000, version: VERSION, fiats: FIATS, signs: FIAT_SIGN,
      status: { ...status, now: Date.now() },
    });
  }
  if (path === "/api/market") {
    const fiat = FIATS.includes(url.searchParams.get("fiat") || "") ? url.searchParams.get("fiat")! : u.fiat || "RUB";
    marketWanted.set(fiat, Date.now());
    let m = markets.get(fiat);
    if (!m || Date.now() - m.at > Math.max(15000, POLL_MS * 2)) m = await loadMarket(fiat);
    const counts = new Map<string, number>();
    for (const a of m.ads) for (const p of a.payments) counts.set(p, (counts.get(p) || 0) + 1);
    const ids = new Set<string>([...(fiatPays.get(fiat) || []), ...counts.keys()]);
    const payments = [...ids].map((id) => ({ id, name: payName(id), count: counts.get(id) || 0 }))
      .filter((p) => !p.name.startsWith("Метод #") || p.count)
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    return json({ fiat, sign: sign(fiat), at: m.at, total: m.total, error: m.error, ads: m.ads.slice(0, 200).map((a) => ({ ...a, url: adUrl(a) })), payments, listUrl: listUrl(fiat) });
  }
  if (path === "/api/hits") {
    return json({ hits: q.hitsOf.all(u.id).map((h: any) => { const a = safeJson<Ad>(h.ad, null as any); return { id: h.id, at: h.created_at, filter: h.filter_name, ad: a && { ...a, url: adUrl(a) } }; }).filter((h: any) => h.ad) });
  }
  if (req.method !== "POST" && req.method !== "DELETE") return json({ error: "method" }, 405);
  const body: any = req.method === "POST" ? await req.json().catch(() => ({})) : {};

  if (path === "/api/filters") {
    const fiat = FIATS.includes(body.fiat) ? body.fiat : "RUB";
    const f = {
      name: String(body.name || "Фильтр").trim().slice(0, 40) || "Фильтр", fiat,
      usdt_min: num(body.usdt_min), usdt_max: num(body.usdt_max), price_min: num(body.price_min), price_max: num(body.price_max),
      payments: JSON.stringify((Array.isArray(body.payments) ? body.payments : []).map(String).slice(0, 30)),
      min_rate: Math.min(100, num(body.min_rate)), min_orders: num(body.min_orders),
      only_online: body.only_online ? 1 : 0, only_verified: body.only_verified ? 1 : 0,
    };
    if (f.usdt_max && f.usdt_min > f.usdt_max) [f.usdt_min, f.usdt_max] = [f.usdt_max, f.usdt_min];
    if (f.price_max && f.price_min > f.price_max) [f.price_min, f.price_max] = [f.price_max, f.price_min];
    let id = Number(body.id) || 0;
    if (id) {
      if (!q.filter.get(id, u.id)) return json({ error: "not found" }, 404);
      db.query("UPDATE filters SET name=?,fiat=?,usdt_min=?,usdt_max=?,price_min=?,price_max=?,payments=?,min_rate=?,min_orders=?,only_online=?,only_verified=? WHERE id=? AND user_id=?")
        .run(f.name, f.fiat, f.usdt_min, f.usdt_max, f.price_min, f.price_max, f.payments, f.min_rate, f.min_orders, f.only_online, f.only_verified, id, u.id);
      q.seenClearFilter.run(id); // после изменения фильтра пришлём актуальные совпадения заново
    } else {
      if (q.filtersOf.all(u.id).length >= 20) return json({ error: "Максимум 20 фильтров" }, 400);
      const r = db.query("INSERT INTO filters(user_id,name,fiat,usdt_min,usdt_max,price_min,price_max,payments,min_rate,min_orders,only_online,only_verified,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?)")
        .run(u.id, f.name, f.fiat, f.usdt_min, f.usdt_max, f.price_min, f.price_max, f.payments, f.min_rate, f.min_orders, f.only_online, f.only_verified, Date.now());
      id = Number(r.lastInsertRowid);
    }
    db.query("UPDATE users SET fiat=? WHERE id=?").run(fiat, u.id);
    setTimeout(tick, 300);
    return json({ ok: true, id });
  }
  const mt = path.match(/^\/api\/filters\/(\d+)(\/toggle)?$/);
  if (mt) {
    const id = Number(mt[1]);
    if (!q.filter.get(id, u.id)) return json({ error: "not found" }, 404);
    if (mt[2]) {
      db.query("UPDATE filters SET active=1-active WHERE id=? AND user_id=?").run(id, u.id);
      q.seenClearFilter.run(id);
      setTimeout(tick, 300);
    } else if (req.method === "DELETE") {
      db.query("DELETE FROM filters WHERE id=? AND user_id=?").run(id, u.id);
      q.seenClearFilter.run(id);
    }
    return json({ ok: true });
  }
  if (path === "/api/settings") {
    if (typeof body.paused === "boolean") db.query("UPDATE users SET paused=?, pause_until=0 WHERE id=?").run(body.paused ? 1 : 0, u.id);
    if (typeof body.silent === "boolean") db.query("UPDATE users SET silent=? WHERE id=?").run(body.silent ? 1 : 0, u.id);
    if (typeof body.pauseMinutes === "number") db.query("UPDATE users SET pause_until=? WHERE id=?").run(body.pauseMinutes > 0 ? Date.now() + body.pauseMinutes * 60000 : 0, u.id);
    if (FIATS.includes(body.fiat)) db.query("UPDATE users SET fiat=? WHERE id=?").run(body.fiat, u.id);
    return json({ ok: true });
  }
  if (path === "/api/blacklist") {
    let list = bl.filter((b) => b.id !== String(body.id));
    if (!body.remove && body.id) list.push({ id: String(body.id), nick: String(body.nick || "продавец").slice(0, 40) });
    db.query("UPDATE users SET blacklist=? WHERE id=?").run(JSON.stringify(list), u.id);
    return json({ ok: true, blacklist: list });
  }
  if (path === "/api/test") {
    const fiat = u.fiat || "RUB";
    const m = markets.get(fiat) || (await loadMarket(fiat));
    const a = m.ads.find((x) => !bl.some((b) => b.id === x.maskId));
    if (!a) return json({ error: "Стакан Bybit сейчас недоступен" }, 502);
    await send(u.id, adText(a, null, "Тестовое уведомление"), { reply_markup: adKeyboard(a), disable_notification: !!u.silent });
    return json({ ok: true });
  }
  return json({ error: "not found" }, 404);
}

Bun.serve({
  port: PORT,
  idleTimeout: 60,
  async fetch(req) {
    const url = new URL(req.url);
    try {
      if (url.pathname.startsWith("/api/")) return await api(req, url);
      if (url.pathname === "/health") return json({ ok: true, version: VERSION, bot: botUsername, webapp: WEBAPP_URL, ...status });
      if (url.pathname === "/logo.svg") return new Response(LOGO_SVG, { headers: { "content-type": "image/svg+xml", "cache-control": "public, max-age=86400" } });
      if (url.pathname === "/" || url.pathname === "/index.html")
        return new Response(APP_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache" } });
      return new Response("Not found", { status: 404 });
    } catch (e: any) {
      log("http error", url.pathname, e?.message || e);
      return json({ error: "server error" }, 500);
    }
  },
});

log(`P2P Radar ${VERSION} · port ${PORT} · data ${DATA_DIR} · webapp ${WEBAPP_URL || "(нет домена)"} · poll ${POLL_MS / 1000}s`);
await loadPayments();
setInterval(loadPayments, 6 * 3600 * 1000);
botLoop();
monitorLoop();
