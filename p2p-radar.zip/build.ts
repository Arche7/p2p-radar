// Сборка: склеивает src/server.ts + src/app.html + brand/logo-mark.svg в один файл index.tsx
// Запуск: bun build.ts
const server = await Bun.file("src/server.ts").text();
const html = await Bun.file("src/app.html").text();
const logo = await Bun.file("brand/logo-mark.svg").text();

// HTML вставляется как шаблонная строка `...`,
// поэтому в app.html и logo-mark.svg нельзя использовать обратные кавычки, ${ и обратный слэш.
for (const [name, txt] of [["app.html", html], ["logo-mark.svg", logo]]) {
  if (txt.includes("`") || txt.includes("${") || txt.includes("\\")) {
    throw new Error(name + ": нельзя использовать обратные кавычки, ${ и обратный слэш");
  }
}

const out = server
  .replace("__APP_HTML__", () => "`" + html + "`")
  .replace("__LOGO_SVG__", () => "`" + logo.trim() + "`");

await Bun.write("index.tsx", "// ⚠️ Этот файл собирается автоматически командой `bun build.ts` из папки src/. Правьте исходники в src/.\n" + out);
console.log(`index.tsx: ${(out.length / 1024).toFixed(1)} KB`);
