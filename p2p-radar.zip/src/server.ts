// ─────────────────────────────────────────────────────────────────────────────
//  P2P Radar — Telegram-бот + Mini App для мониторинга Bybit P2P (покупка USDT)
//  Один файл, без внешних зависимостей. Рантайм: Bun (bun:sqlite встроен).
// ─────────────────────────────────────────────────────────────────────────────
import { Database } from "bun:sqlite";
import { createHmac } from "node:crypto";
import { mkdirSync } from "node:fs";

// Эти две константы подставляет build.ts (HTML мини-приложения и логотип)
const APP_HTML: string = __APP_HTML__;
const LOGO_SVG: string = __LOGO_SVG__;

// ───────────── Настройки (переменные окружения Railway) ─────────────
const env = Bun.env;
const VERSION = "1.0.0";
const BOT_TOKEN = (env.BOT_TOKEN || "").trim();
const PORT = Number(env.PORT || 3000);
const DATA_DIR = env.DATA_DIR || env.RAILWAY_VOLUME_MOUNT_PATH || "./data";
const WEBAPP_URL = (env.WEBAPP_URL || (env.RAILWAY_PUBLIC_DOMAIN ? `https://${env.RAILWAY_PUBLIC_DOMAIN}` : "")).replace(/\/$/, "");
const POLL_MS = Math.max(3, Number(env.POLL_SECONDS || 6)) * 1000;
const MAX_PAGES = Math.min(10, Math.max(1, Number(env.MAX_PAGES || 4)));
const PAGE_SIZE = 50;
const PROXY_URL = env.PROXY_URL || "";
const DEV = env.DEV === "1";
const ALLOWED = (env.ALLOWED_USERS || "").split(/[\s,;]+/).filter(Boolean).map(Number);
const MAX_PER_TICK = 5; // сколько карточек максимум отправлять за один цикл на фильтр
const REAPPEAR_MS = 30 * 60 * 1000; // объявление «вернулось» спустя 30 мин → уведомим снова
const FIATS = ["RUB", "KZT", "UAH", "BYN", "USD", "EUR", "UZS", "KGS", "GEL", "TRY", "AZN", "AMD"];
const FIAT_SIGN: Record<string, string> = { RUB: "₽", KZT: "₸", UAH: "₴", BYN: "Br", USD: "$", EUR: "€", UZS: "сўм", KGS: "сом", GEL: "₾", TRY: "₺", AZN: "₼", AMD: "֏" };

const log = (...a: any[]) => console.log(new Date().toISOString().slice(11, 19), ...a);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ───────────── База данных (SQLite на томе /data) ─────────────
mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(`${DATA_DIR}/radar.db`, { create: true });
db.exec("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=3000;");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT, username TEXT,
  paused INTEGER DEFAULT 0, silent INTEGER DEFAULT 0, pause_until INTEGER DEFAULT 0,
  blacklist TEXT DEFAULT '[]', fiat TEXT DEFAULT 'RUB', created_at INTEGER);
CREATE TABLE IF NOT EXISTS filters(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT, fiat TEXT,
  usdt_min REAL, usdt_max REAL, price_min REAL, price_max REAL, payments TEXT DEFAULT '[]',
  min_rate INTEGER DEFAULT 0, min_orders INTEGER DEFAULT 0, only_online INTEGER DEFAULT 0,
  only_verified INTEGER DEFAULT 0, active INTEGER DEFAULT 1, created_at INTEGER);
CREATE TABLE IF NOT EXISTS seen(
  filter_id INTEGER, ad_id TEXT, price REAL, notified_at INTEGER, last_match INTEGER,
  PRIMARY KEY(filter_id, ad_id));
CREATE TABLE IF NOT EXISTS hits(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, filter_id INTEGER, filter_name TEXT,
  ad TEXT, created_at INTEGER);
CREATE INDEX IF NOT EXISTS hits_user ON hits(user_id, id);
`);

type User = { id: number; name: string; username: string; paused: number; silent: number; pause_until: number; blacklist: string; fiat: string; created_at: number };
type Filter = {
  id: number; user_id: number; name: string; fiat: string; usdt_min: number; usdt_max: number;
  price_min: number; price_max: number; payments: string[]; min_rate: number; min_orders: number;
  only_online: number; only_verified: number; active: number; created_at: number;
};
type Ad = {
  id: string; maskId: string; nick: string; fiat: string; price: number; minFiat: number; maxFiat: number;
  qty: number; minUsdt: number; maxUsdt: number; payments: string[]; orders: number; rate: number;
  online: boolean; verified: boolean; tags: string[]; period: number;
  req: { kyc: boolean; regDays: number; orders30: number; rate30: number }; remark: string;
};

const q = {
  user: db.query<User, [number]>("SELECT * FROM users WHERE id=?"),
  upsertUser: db.query("INSERT INTO users(id,name,username,created_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, username=excluded.username"),
  filtersOf: db.query<any, [number]>("SELECT * FROM filters WHERE user_id=? ORDER BY id"),
  filter: db.query<any, [number, number]>("SELECT * FROM filters WHERE id=? AND user_id=?"),
  activeFilters: db.query<any, [number]>(
    "SELECT f.* FROM filters f JOIN users u ON u.id=f.user_id WHERE f.active=1 AND u.paused=0 AND u.pause_until<?"),
  seenGet: db.query<{ price: number; notified_at: number; last_match: number }, [number, string]>(
    "SELECT price,notified_at,last_match FROM seen WHERE filter_id=? AND ad_id=?"),
  seenPut: db.query("INSERT INTO seen(filter_id,ad_id,price,notified_at,last_match) VALUES(?,?,?,?,?) ON CONFLICT(filter_id,ad_id) DO UPDATE SET price=excluded.price, notified_at=excluded.notified_at, last_match=excluded.last_match"),
  seenClearFilter: db.query("DELETE FROM seen WHERE filter_id=?"),
  seenGc: db.query("DELETE FROM seen WHERE last_match<?"),
  hitAdd: db.query("INSERT INTO hits(user_id,filter_id,filter_name,ad,created_at) VALUES(?,?,?,?,?)"),
  hitsOf: db.query<any, [number]>("SELECT * FROM hits WHERE user_id=? ORDER BY id DESC LIMIT 60"),
  hitsGc: db.query("DELETE FROM hits WHERE created_at<?"),
};

const parseFilter = (r: any): Filter => ({ ...r, payments: safeJson(r.payments, []) });
function safeJson<T>(s: string, d: T): T { try { return JSON.parse(s) ?? d; } catch { return d; } }
function ensureUser(u: { id: number; first_name?: string; last_name?: string; username?: string }) {
  const name = [u.first_name, u.last_name].filter(Boolean).join(" ") || "друг";
  q.upsertUser.run(u.id, name, u.username || "", Date.now());
  return q.user.get(u.id)!;
}
const blacklistOf = (u: User | null): { id: string; nick: string }[] => (u ? safeJson(u.blacklist, []) : []);

// ───────────── Bybit P2P ─────────────
const BYBIT_HEADERS = {
  "content-type": "application/json;charset=UTF-8",
  accept: "application/json",
  "accept-language": "ru-RU,ru;q=0.9,en;q=0.8",
  origin: "https://www.bybit.com",
  referer: "https://www.bybit.com/",
  "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0 Safari/537.36",
};
const fetchOpts = (o: RequestInit): RequestInit => (PROXY_URL ? ({ ...o, proxy: PROXY_URL } as any) : o);

function norm(x: any, fiat: string): Ad | null {
  const price = +x.price;
  if (!(price > 0)) return null;
  if (x.side !== undefined && +x.side !== 1) return null; // нужны только объявления «продавец продаёт USDT»
  const minFiat = +x.minAmount || 0, maxFiat = +x.maxAmount || 0, qty = +x.lastQuantity || 0;
  const tp = x.tradingPreferenceSet || {};
  const tags: string[] = Array.isArray(x.authTag) ? x.authTag.map(String) : [];
  return {
    id: String(x.id), maskId: String(x.userMaskId || ""), nick: String(x.nickName || "—"), fiat, price,
    minFiat, maxFiat, qty, minUsdt: minFiat / price, maxUsdt: Math.min(maxFiat / price, qty),
    payments: (x.payments || []).map(String), orders: +x.recentOrderNum || 0, rate: +x.recentExecuteRate || 0,
    online: !!x.isOnline, verified: tags.includes("VA") || tags.includes("BA"), tags, period: +x.paymentPeriod || 0,
    req: {
      kyc: !!tp.isKyc,
      regDays: tp.hasRegisterTime ? +tp.registerTimeThreshold || 0 : 0,
      orders30: tp.hasOrderFinishNumberDay30 ? +tp.orderFinishNumberDay30 || 0 : 0,
      rate30: tp.hasCompleteRateDay30 ? +tp.completeRateDay30 || 0 : 0,
    },
    remark: String(x.remark || "").slice(0, 500),
  };
}

async function bybitPage(fiat: string, page: number) {
  const body = { userId: "", tokenId: "USDT", currencyId: fiat, payment: [], side: "1", size: String(PAGE_SIZE), page: String(page), amount: "", authMaker: false, canTrade: false };
  const r = await fetch("https://api2.bybit.com/fiat/otc/item/online",
    fetchOpts({ method: "POST", headers: BYBIT_HEADERS, body: JSON.stringify(body), signal: AbortSignal.timeout(12000) }));
  if (!r.ok) throw new Error(`Bybit HTTP ${r.status}`);
  const j: any = await r.json();
  if (j.ret_code !== 0) throw new Error(`Bybit: ${j.ret_msg}`);
  return { items: (j.result?.items || []) as any[], count: +j.result?.count || 0 };
}

type Market = { fiat: string; ads: Ad[]; total: number; at: number; error: string };
const markets = new Map<string, Market>();
const marketWanted = new Map<string, number>(); // валюты, которые недавно смотрели в приложении

async function loadMarket(fiat: string, priceCap = Infinity): Promise<Market> {
  const ads: Ad[] = [];
  let total = 0;
  try {
    for (let p = 1; p <= MAX_PAGES; p++) {
      const { items, count } = await bybitPage(fiat, p);
      total = count;
      for (const it of items) { const a = norm(it, fiat); if (a) ads.push(a); }
      if (items.length < PAGE_SIZE) break;
      const last = ads[ads.length - 1];
      if (!last || last.price > priceCap) break; // дальше только дороже — не нужно
    }
    ads.sort((a, b) => a.price - b.price);
    const m = { fiat, ads, total, at: Date.now(), error: "" };
    markets.set(fiat, m);
    return m;
  } catch (e: any) {
    const prev = markets.get(fiat);
    const m = { fiat, ads: prev?.ads || [], total: prev?.total || 0, at: prev?.at || 0, error: String(e?.message || e) };
    markets.set(fiat, m);
    log("bybit error", fiat, m.error);
    return m;
  }
}

// Названия способов оплаты (Тинькофф, СБП…) — берём у Bybit, обновляем раз в 6 часов
const payNames = new Map<string, string>();
const fiatPays = new Map<string, string[]>();
const PAY_RU: Record<string, string> = {
  Tinkoff: "Т-Банк", "T-Bank": "Т-Банк", Sberbank: "Сбербанк", SBP: "СБП", "SBP - Fast Bank Transfer": "СБП",
  Raiffeisenbank: "Райффайзен", "Alfa Bank": "Альфа-Банк", "Alfa-Bank": "Альфа-Банк", VTB: "ВТБ", "VTB Bank": "ВТБ",
  "Bank Transfer": "Банковский перевод", Cash: "Наличные", "Cash Deposit to Bank": "Внесение наличных",
  "Gazprombank": "Газпромбанк", "Rosbank": "Росбанк", "Ozon Bank": "Озон Банк", "Yandex Pay": "Яндекс Пэй",
  "MTS Bank": "МТС Банк", "Pochta Bank": "Почта Банк", "Sovcombank": "Совкомбанк", "Home Credit Bank": "Хоум Банк",
  "Russian Standard Bank": "Русский Стандарт", "Otkritie": "Открытие", "Uralsib": "Уралсиб", "Mir": "МИР",
  "QIWI": "QIWI", "YooMoney": "ЮMoney", "Kaspi Bank": "Kaspi", "Monobank": "Monobank", "PrivatBank": "ПриватБанк",
};
async function loadPayments() {
  try {
    const r = await fetch("https://api2.bybit.com/fiat/otc/configuration/queryAllPaymentList",
      fetchOpts({ method: "POST", headers: BYBIT_HEADERS, body: "{}", signal: AbortSignal.timeout(20000) }));
    const j: any = await r.json();
    for (const p of j?.result?.paymentConfigVo || []) {
      const name = String(p.paymentName || "").trim();
      if (name) payNames.set(String(p.paymentType), PAY_RU[name] || name);
    }
    const map = safeJson<Record<string, number[]>>(j?.result?.currencyPaymentIdMap || "{}", {});
    for (const [fiat, ids] of Object.entries(map)) fiatPays.set(fiat, ids.map(String));
    log(`payments loaded: ${payNames.size}`);
  } catch (e: any) { log("payments error", e?.message || e); }
}
const payName = (id: string) => payNames.get(id) || `Метод #${id}`;

// ───────────── Подбор объявлений под фильтр ─────────────
function matches(a: Ad, f: Filter, bl: { id: string }[]) {
  if (a.fiat !== f.fiat) return false;
  if (f.price_min && a.price < f.price_min) return false;
  if (f.price_max && a.price > f.price_max) return false;
  if (a.maxUsdt + 1e-9 < a.minUsdt) return false; // у продавца осталось меньше, чем его же минимальный лимит
  if (f.usdt_max && a.minUsdt > f.usdt_max + 1e-9) return false; // минимум продавца больше вашего максимума
  if (f.usdt_min && a.maxUsdt + 1e-9 < f.usdt_min) return false; // у продавца нельзя купить даже ваш минимум
  if (f.payments.length && !a.payments.some((p) => f.payments.includes(p))) return false;
  if (f.min_rate && a.rate < f.min_rate) return false;
  if (f.min_orders && a.orders < f.min_orders) return false;
  if (f.only_online && !a.online) return false;
  if (f.only_verified && !a.verified) return false;
  if (bl.some((b) => b.id === a.maskId)) return false;
  return true;
}

// ───────────── Ссылки на Bybit ─────────────
const listUrl = (fiat: string) => `https://www.bybit.com/fiat/trade/otc/buy/USDT/${fiat}`;
const adUrl = (a: Ad) => (a.maskId ? `https://www.bybit.com/fiat/trade/otc/profile/${a.maskId}/USDT/${a.fiat}/item` : listUrl(a.fiat));

// ───────────── Telegram Bot API (без библиотек) ─────────────
let botUsername = "";
async function tg(method: string, payload: any = {}, attempt = 0): Promise<any> {
  if (!BOT_TOKEN) throw new Error("BOT_TOKEN не задан");
  const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload),
    signal: AbortSignal.timeout(method === "getUpdates" ? 40000 : 15000),
  });
  const j: any = await r.json().catch(() => ({ ok: false, description: `HTTP ${r.status}` }));
  if (j.ok) return j.result;
  if (j.parameters?.retry_after && attempt < 3) { await sleep((j.parameters.retry_after + 1) * 1000); return tg(method, payload, attempt + 1); }
  const err: any = new Error(`${method}: ${j.description}`);
  err.code = j.error_code;
  throw err;
}

// Очередь отправки, чтобы не упираться в лимиты Telegram
let sendChain = Promise.resolve();
function send(chatId: number, text: string, extra: any = {}) {
  sendChain = sendChain.then(async () => {
    try {
      await tg("sendMessage", { chat_id: chatId, text, parse_mode: "HTML", link_preview_options: { is_disabled: true }, ...extra });
    } catch (e: any) {
      log("send error", chatId, e.message);
      if (e.code === 403) db.query("UPDATE users SET paused=1 WHERE id=?").run(chatId); // пользователь заблокировал бота
    }
    await sleep(70);
  });
  return sendChain;
}

const esc = (s: any) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const fmt = (n: number, d = 2) => n.toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d }).replace(/ /g, " ");
const fmtQ = (n: number) => fmt(n, n >= 1000 ? 0 : 2);
const sign = (f: string) => FIAT_SIGN[f] || f;

function adText(a: Ad, f: Filter | null, title = "Новое объявление") {
  const s = sign(a.fiat);
  const buyMin = Math.max(a.minUsdt, f?.usdt_min || 0), buyMax = Math.min(a.maxUsdt, f?.usdt_max || Infinity);
  const req: string[] = [];
  if (a.req.regDays) req.push(`аккаунт от ${a.req.regDays} дн.`);
  if (a.req.orders30) req.push(`от ${a.req.orders30} сделок/30д`);
  if (a.req.rate30) req.push(`от ${a.req.rate30}% завершения`);
  const lines = [
    `🟢 <b>${esc(title)}</b>${f ? ` · ${esc(f.name)}` : ""}`,
    ``,
    `💵 <b>${fmt(a.price)} ${s}</b> за 1 USDT`,
    `📦 Можно купить: <b>${fmtQ(buyMin)} – ${fmtQ(buyMax)} USDT</b>`,
    `↔️ Лимит: ${fmtQ(a.minFiat)} – ${fmtQ(a.maxFiat)} ${s} · доступно ${fmtQ(a.qty)} USDT`,
    `💳 ${esc(a.payments.map(payName).join(", ") || "—")}`,
    `👤 <b>${esc(a.nick)}</b>${a.verified ? " ✔️" : ""} · ${a.rate}% · ${a.orders} сделок · ${a.online ? "🟢 онлайн" : "⚪️ офлайн"}`,
    a.period ? `⏱ Время на оплату: ${a.period} мин` : "",
    req.length ? `⚠️ Требования: ${esc(req.join(", "))}` : "",
  ];
  return lines.filter((l, i) => l !== "" || i === 1).join("\n");
}
function adKeyboard(a: Ad) {
  const rows: any[] = [[{ text: "⚡ Открыть в Bybit", url: adUrl(a) }]];
  const row2: any[] = [];
  if (WEBAPP_URL) row2.push({ text: "📡 Радар", web_app: { url: WEBAPP_URL } });
  row2.push({ text: "🙈 Скрыть продавца", callback_data: `bl:${a.maskId}`.slice(0, 64) });
  rows.push(row2);
  rows.push([{ text: "⏸ Пауза 1 ч", callback_data: "p60" }, { text: "📋 Весь стакан", url: listUrl(a.fiat) }]);
  return { inline_keyboard: rows };
}

// ───────────── Монитор ─────────────
const status = { lastTick: 0, tickMs: 0, ok: true, error: "", started: Date.now(), sent: 0 };
let ticking = false;

async function tick() {
  if (ticking) return;
  ticking = true;
  const t0 = Date.now();
  try {
    const now = Date.now();
    const filters = q.activeFilters.all(now).map(parseFilter);
    const fiats = new Set<string>(filters.map((f) => f.fiat));
    for (const [f, at] of marketWanted) if (now - at < 120000) fiats.add(f); else marketWanted.delete(f);
    let anyError = "";
    for (const fiat of fiats) {
      const fs = filters.filter((f) => f.fiat === fiat);
      const cap = fs.length && fs.every((f) => f.price_max > 0) ? Math.max(...fs.map((f) => f.price_max)) : Infinity;
      const m = await loadMarket(fiat, fs.length ? cap : Infinity);
      if (m.error) { anyError = m.error; continue; }
      for (const f of fs) await processFilter(f, m.ads);
    }
    status.ok = !anyError;
    status.error = anyError;
  } catch (e: any) {
    status.ok = false; status.error = String(e?.message || e); log("tick error", status.error);
  } finally {
    status.lastTick = Date.now();
    status.tickMs = Date.now() - t0;
    ticking = false;
  }
}

async function processFilter(f: Filter, ads: Ad[]) {
  const u = q.user.get(f.user_id);
  if (!u) return;
  const bl = blacklistOf(u);
  const now = Date.now();
  const fresh: { a: Ad; cheaper: boolean }[] = [];
  for (const a of ads) {
    if (!matches(a, f, bl)) continue;
    const s = q.seenGet.get(f.id, a.id);
    const isNew = !s || now - s.last_match > REAPPEAR_MS;
    const cheaper = !!s && !isNew && a.price < s.price - 1e-9;
    if (isNew || cheaper) fresh.push({ a, cheaper });
    q.seenPut.run(f.id, a.id, isNew || cheaper ? a.price : s!.price, isNew || cheaper ? now : s!.notified_at, now);
  }
  if (!fresh.length) return;
  fresh.sort((x, y) => x.a.price - y.a.price);
  const silent = !!u.silent;
  for (const { a, cheaper } of fresh.slice(0, MAX_PER_TICK)) {
    q.hitAdd.run(u.id, f.id, f.name, JSON.stringify(a), now);
    send(u.id, adText(a, f, cheaper ? "Подешевело" : "Новое объявление"), { reply_markup: adKeyboard(a), disable_notification: silent });
    status.sent++;
  }
  const rest = fresh.length - MAX_PER_TICK;
  if (rest > 0) {
    for (const { a } of fresh.slice(MAX_PER_TICK)) q.hitAdd.run(u.id, f.id, f.name, JSON.stringify(a), now);
    send(u.id, `➕ И ещё <b>${rest}</b> подходящих объявлений по фильтру «${esc(f.name)}». Все — в приложении.`, {
      disable_notification: true,
      reply_markup: WEBAPP_URL ? { inline_keyboard: [[{ text: "📡 Открыть радар", web_app: { url: WEBAPP_URL + "#feed" } }]] } : undefined,
    });
  }
}

async function monitorLoop() {
  let n = 0;
  for (;;) {
    await tick();
    if (++n % 600 === 0) { // уборка примерно раз в час
      q.seenGc.run(Date.now() - 86400000);
      q.hitsGc.run(Date.now() - 7 * 86400000);
    }
    await sleep(POLL_MS);
  }
}

// ───────────── Команды бота ─────────────
const appButton = (text = "📡 Открыть радар") => (WEBAPP_URL ? { inline_keyboard: [[{ text, web_app: { url: WEBAPP_URL } }]] } : undefined);

async function handleUpdate(up: any) {
  if (up.callback_query) return handleCallback(up.callback_query);
  const m = up.message;
  if (!m?.from || m.chat?.type !== "private") return;
  if (ALLOWED.length && !ALLOWED.includes(m.from.id)) {
    return send(m.chat.id, "🔒 Это приватный бот. Доступ только для владельца.");
  }
  const u = ensureUser(m.from);
  const text: string = (m.text || "").trim();
  const cmd = text.split(/[\s@]/)[0].toLowerCase();
  if (cmd === "/start" || cmd === "/app") {
    return send(u.id, [
      `👋 <b>${esc(u.name)}, это P2P Radar</b>`,
      ``,
      `Я слежу за объявлениями <b>Bybit P2P</b> на покупку USDT и присылаю их сразу, как только появляется подходящее.`,
      ``,
      `1️⃣ Откройте радар и задайте фильтр: сколько USDT нужно и по какому курсу`,
      `2️⃣ Я проверяю стакан каждые ${POLL_MS / 1000} сек.`,
      `3️⃣ Пришло объявление → жмите «⚡ Открыть в Bybit» и покупайте`,
    ].join("\n"), { reply_markup: appButton() });
  }
  if (cmd === "/filters") {
    const fs = q.filtersOf.all(u.id).map(parseFilter);
    if (!fs.length) return send(u.id, "Фильтров пока нет. Создайте первый в радаре 👇", { reply_markup: appButton("➕ Создать фильтр") });
    const lines = fs.map((f) => `${f.active ? "🟢" : "⚪️"} <b>${esc(f.name)}</b>\n    ${fmtQ(f.usdt_min)}–${f.usdt_max ? fmtQ(f.usdt_max) : "∞"} USDT · курс ${f.price_min ? fmt(f.price_min) : "0"}–${f.price_max ? fmt(f.price_max) : "∞"} ${sign(f.fiat)}`);
    return send(u.id, `<b>Ваши фильтры</b>\n\n${lines.join("\n")}`, { reply_markup: appButton("✏️ Изменить") });
  }
  if (cmd === "/pause") {
    db.query("UPDATE users SET paused=1 WHERE id=?").run(u.id);
    return send(u.id, "⏸ Уведомления на паузе. Включить: /resume");
  }
  if (cmd === "/resume") {
    db.query("UPDATE users SET paused=0, pause_until=0 WHERE id=?").run(u.id);
    return send(u.id, "▶️ Мониторинг снова работает.");
  }
  if (cmd === "/best") {
    const m = markets.get(u.fiat || "RUB") || (await loadMarket(u.fiat || "RUB"));
    const a = m.ads[0];
    if (!a) return send(u.id, "Не удалось получить стакан Bybit, попробуйте позже.");
    return send(u.id, adText(a, null, "Лучший курс сейчас"), { reply_markup: adKeyboard(a) });
  }
  return send(u.id, [
    `<b>Команды</b>`,
    `/start — открыть радар`,
    `/filters — мои фильтры`,
    `/best — лучшее объявление прямо сейчас`,
    `/pause — пауза уведомлений`,
    `/resume — возобновить`,
  ].join("\n"), { reply_markup: appButton() });
}

async function handleCallback(cq: any) {
  const id = cq.from.id;
  const data: string = cq.data || "";
  const u = q.user.get(id);
  let answer = "Готово";
  if (u && data.startsWith("bl:")) {
    const mask = data.slice(3);
    const bl = blacklistOf(u);
    if (!bl.some((b) => b.id === mask)) {
      const nick = (cq.message?.text || "").match(/👤 ([^\n·]+?)(?: ✔️)? ·/)?.[1]?.trim() || "продавец";
      bl.push({ id: mask, nick });
      db.query("UPDATE users SET blacklist=? WHERE id=?").run(JSON.stringify(bl), id);
    }
    answer = "Продавец скрыт. Вернуть можно в настройках радара.";
  } else if (u && data === "p60") {
    db.query("UPDATE users SET pause_until=? WHERE id=?").run(Date.now() + 3600000, id);
    answer = "⏸ Пауза на 1 час";
  }
  await tg("answerCallbackQuery", { callback_query_id: cq.id, text: answer }).catch(() => {});
}

async function botLoop() {
  if (!BOT_TOKEN) { log("⚠️  BOT_TOKEN не задан — бот не запущен (сайт и API работают)"); return; }
  try {
    const me = await tg("getMe");
    botUsername = me.username;
    log(`bot @${botUsername}`);
    await tg("deleteWebhook", { drop_pending_updates: false });
    await tg("setMyCommands", { commands: [
      { command: "start", description: "Открыть радар" },
      { command: "filters", description: "Мои фильтры" },
      { command: "best", description: "Лучший курс сейчас" },
      { command: "pause", description: "Пауза уведомлений" },
      { command: "resume", description: "Возобновить" },
    ] });
    if (WEBAPP_URL) await tg("setChatMenuButton", { menu_button: { type: "web_app", text: "Радар", web_app: { url: WEBAPP_URL } } });
    await tg("setMyShortDescription", { short_description: "Мгновенные уведомления о выгодных объявлениях Bybit P2P на покупку USDT." }).catch(() => {});
    await tg("setMyDescription", { description: "📡 P2P Radar следит за стаканом Bybit P2P и сразу присылает объявления на покупку USDT под ваш курс и сумму. Нажмите «Старт», чтобы настроить фильтр." }).catch(() => {});
  } catch (e: any) { log("bot setup error", e.message); }
  let offset = 0;
  for (;;) {
    try {
      const ups = await tg("getUpdates", { offset, timeout: 30, allowed_updates: ["message", "callback_query"] });
      for (const up of ups) {
        offset = up.update_id + 1;
        handleUpdate(up).catch((e) => log("update error", e.message));
      }
    } catch (e: any) {
      log("getUpdates", e.message);
      await sleep(e.code === 409 ? 8000 : 3000);
    }
  }
}

// ───────────── Проверка подписи Telegram Mini App ─────────────
function authUser(req: Request): User | null {
  const init = req.headers.get("x-init-data") || "";
  if (!init) return DEV ? ensureUser({ id: 1, first_name: "Dev" }) : null;
  const p = new URLSearchParams(init);
  const hash = p.get("hash");
  if (!hash || !BOT_TOKEN) return null;
  p.delete("hash");
  const dcs = [...p.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)).map(([k, v]) => `${k}=${v}`).join("\n");
  const secret = createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  if (createHmac("sha256", secret).update(dcs).digest("hex") !== hash) return null;
  if (Date.now() / 1000 - Number(p.get("auth_date") || 0) > 7 * 86400) return null;
  const tu = safeJson<any>(p.get("user") || "{}", {});
  if (!tu.id) return null;
  if (ALLOWED.length && !ALLOWED.includes(tu.id)) return null;
  return ensureUser(tu);
}

// ───────────── HTTP API для Mini App ─────────────
const json = (data: any, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const num = (v: any, d = 0) => { const n = Number(String(v ?? "").replace(",", ".").replace(/\s/g, "")); return Number.isFinite(n) && n >= 0 ? n : d; };

function filterOut(f: Filter, bl: { id: string }[]) {
  const m = markets.get(f.fiat);
  const ms = m ? m.ads.filter((a) => matches(a, f, bl)) : [];
  return { ...f, matchCount: ms.length, best: ms[0]?.price || 0 };
}

async function api(req: Request, url: URL): Promise<Response> {
  const u = authUser(req);
  if (!u) return json({ error: ALLOWED.length ? "forbidden" : "unauthorized" }, 401);
  const path = url.pathname;
  const bl = blacklistOf(u);

  if (path === "/api/state") {
    return json({
      user: { id: u.id, name: u.name, paused: !!u.paused, silent: !!u.silent, pauseUntil: u.pause_until > Date.now() ? u.pause_until : 0, fiat: u.fiat, blacklist: bl },
      filters: q.filtersOf.all(u.id).map(parseFilter).map((f) => filterOut(f, bl)),
      bot: botUsername, poll: POLL_MS / 1000, version: VERSION, fiats: FIATS, signs: FIAT_SIGN,
      status: { ...status, now: Date.now() },
    });
  }
  if (path === "/api/market") {
    const fiat = FIATS.includes(url.searchParams.get("fiat") || "") ? url.searchParams.get("fiat")! : u.fiat || "RUB";
    marketWanted.set(fiat, Date.now());
    let m = markets.get(fiat);
    if (!m || Date.now() - m.at > Math.max(15000, POLL_MS * 2)) m = await loadMarket(fiat);
    const counts = new Map<string, number>();
    for (const a of m.ads) for (const p of a.payments) counts.set(p, (counts.get(p) || 0) + 1);
    const ids = new Set<string>([...(fiatPays.get(fiat) || []), ...counts.keys()]);
    const payments = [...ids].map((id) => ({ id, name: payName(id), count: counts.get(id) || 0 }))
      .filter((p) => !p.name.startsWith("Метод #") || p.count)
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    return json({ fiat, sign: sign(fiat), at: m.at, total: m.total, error: m.error, ads: m.ads.slice(0, 200).map((a) => ({ ...a, url: adUrl(a) })), payments, listUrl: listUrl(fiat) });
  }
  if (path === "/api/hits") {
    return json({ hits: q.hitsOf.all(u.id).map((h: any) => { const a = safeJson<Ad>(h.ad, null as any); return { id: h.id, at: h.created_at, filter: h.filter_name, ad: a && { ...a, url: adUrl(a) } }; }).filter((h: any) => h.ad) });
  }
  if (req.method !== "POST" && req.method !== "DELETE") return json({ error: "method" }, 405);
  const body: any = req.method === "POST" ? await req.json().catch(() => ({})) : {};

  if (path === "/api/filters") {
    const fiat = FIATS.includes(body.fiat) ? body.fiat : "RUB";
    const f = {
      name: String(body.name || "Фильтр").trim().slice(0, 40) || "Фильтр", fiat,
      usdt_min: num(body.usdt_min), usdt_max: num(body.usdt_max), price_min: num(body.price_min), price_max: num(body.price_max),
      payments: JSON.stringify((Array.isArray(body.payments) ? body.payments : []).map(String).slice(0, 30)),
      min_rate: Math.min(100, num(body.min_rate)), min_orders: num(body.min_orders),
      only_online: body.only_online ? 1 : 0, only_verified: body.only_verified ? 1 : 0,
    };
    if (f.usdt_max && f.usdt_min > f.usdt_max) [f.usdt_min, f.usdt_max] = [f.usdt_max, f.usdt_min];
    if (f.price_max && f.price_min > f.price_max) [f.price_min, f.price_max] = [f.price_max, f.price_min];
    let id = Number(body.id) || 0;
    if (id) {
      if (!q.filter.get(id, u.id)) return json({ error: "not found" }, 404);
      db.query("UPDATE filters SET name=?,fiat=?,usdt_min=?,usdt_max=?,price_min=?,price_max=?,payments=?,min_rate=?,min_orders=?,only_online=?,only_verified=? WHERE id=? AND user_id=?")
        .run(f.name, f.fiat, f.usdt_min, f.usdt_max, f.price_min, f.price_max, f.payments, f.min_rate, f.min_orders, f.only_online, f.only_verified, id, u.id);
      q.seenClearFilter.run(id); // после изменения фильтра пришлём актуальные совпадения заново
    } else {
      if (q.filtersOf.all(u.id).length >= 20) return json({ error: "Максимум 20 фильтров" }, 400);
      const r = db.query("INSERT INTO filters(user_id,name,fiat,usdt_min,usdt_max,price_min,price_max,payments,min_rate,min_orders,only_online,only_verified,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?)")
        .run(u.id, f.name, f.fiat, f.usdt_min, f.usdt_max, f.price_min, f.price_max, f.payments, f.min_rate, f.min_orders, f.only_online, f.only_verified, Date.now());
      id = Number(r.lastInsertRowid);
    }
    db.query("UPDATE users SET fiat=? WHERE id=?").run(fiat, u.id);
    setTimeout(tick, 300);
    return json({ ok: true, id });
  }
  const mt = path.match(/^\/api\/filters\/(\d+)(\/toggle)?$/);
  if (mt) {
    const id = Number(mt[1]);
    if (!q.filter.get(id, u.id)) return json({ error: "not found" }, 404);
    if (mt[2]) {
      db.query("UPDATE filters SET active=1-active WHERE id=? AND user_id=?").run(id, u.id);
      q.seenClearFilter.run(id);
      setTimeout(tick, 300);
    } else if (req.method === "DELETE") {
      db.query("DELETE FROM filters WHERE id=? AND user_id=?").run(id, u.id);
      q.seenClearFilter.run(id);
    }
    return json({ ok: true });
  }
  if (path === "/api/settings") {
    if (typeof body.paused === "boolean") db.query("UPDATE users SET paused=?, pause_until=0 WHERE id=?").run(body.paused ? 1 : 0, u.id);
    if (typeof body.silent === "boolean") db.query("UPDATE users SET silent=? WHERE id=?").run(body.silent ? 1 : 0, u.id);
    if (typeof body.pauseMinutes === "number") db.query("UPDATE users SET pause_until=? WHERE id=?").run(body.pauseMinutes > 0 ? Date.now() + body.pauseMinutes * 60000 : 0, u.id);
    if (FIATS.includes(body.fiat)) db.query("UPDATE users SET fiat=? WHERE id=?").run(body.fiat, u.id);
    return json({ ok: true });
  }
  if (path === "/api/blacklist") {
    let list = bl.filter((b) => b.id !== String(body.id));
    if (!body.remove && body.id) list.push({ id: String(body.id), nick: String(body.nick || "продавец").slice(0, 40) });
    db.query("UPDATE users SET blacklist=? WHERE id=?").run(JSON.stringify(list), u.id);
    return json({ ok: true, blacklist: list });
  }
  if (path === "/api/test") {
    const fiat = u.fiat || "RUB";
    const m = markets.get(fiat) || (await loadMarket(fiat));
    const a = m.ads.find((x) => !bl.some((b) => b.id === x.maskId));
    if (!a) return json({ error: "Стакан Bybit сейчас недоступен" }, 502);
    await send(u.id, adText(a, null, "Тестовое уведомление"), { reply_markup: adKeyboard(a), disable_notification: !!u.silent });
    return json({ ok: true });
  }
  return json({ error: "not found" }, 404);
}

Bun.serve({
  port: PORT,
  idleTimeout: 60,
  async fetch(req) {
    const url = new URL(req.url);
    try {
      if (url.pathname.startsWith("/api/")) return await api(req, url);
      if (url.pathname === "/health") return json({ ok: true, version: VERSION, bot: botUsername, webapp: WEBAPP_URL, ...status });
      if (url.pathname === "/logo.svg") return new Response(LOGO_SVG, { headers: { "content-type": "image/svg+xml", "cache-control": "public, max-age=86400" } });
      if (url.pathname === "/" || url.pathname === "/index.html")
        return new Response(APP_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache" } });
      return new Response("Not found", { status: 404 });
    } catch (e: any) {
      log("http error", url.pathname, e?.message || e);
      return json({ error: "server error" }, 500);
    }
  },
});

log(`P2P Radar ${VERSION} · port ${PORT} · data ${DATA_DIR} · webapp ${WEBAPP_URL || "(нет домена)"} · poll ${POLL_MS / 1000}s`);
await loadPayments();
setInterval(loadPayments, 6 * 3600 * 1000);
botLoop();
monitorLoop();
